/**
 * Simplified stub implementation of the RTC client for web
 */
class RtcClient {
  /**
   * Constructor
   */
  constructor() {
    this.rtcEngine = null;
    this.eventHandlers = {};
    this.callbacks = {};
    this.isInitialized = false;
    this.isInRoom = false;
    this.isConversationActive = false;
    this.audioBotActive = false;
    this.currentTaskId = null;
    
    console.log('[RtcClient] Stub implementation created');
  }
  
  /**
   * Initialize the RTC engine
   * @param {Object} config - Configuration parameters
   * @return {boolean} Success indicator
   */
  initialize(config) {
    try {
      console.log('[RtcClient] Initializing with config:', config);
      this.config = config;
      this.isInitialized = true;
      this._fireEvent('initialized', { success: true });
      return true;
    } catch (error) {
      console.error('[RtcClient] Initialization error:', error);
      return false;
    }
  }
  
  /**
   * Join a room
   * @param {Object} options - Room joining options
   * @return {boolean} Success indicator
   */
  joinRoom(options) {
    try {
      console.log('[RtcClient] Joining room with options:', options);
        this.isInRoom = true;
      this._fireEvent('roomJoined', { success: true });
      return true;
      } catch (error) {
      console.error('[RtcClient] Error joining room:', error);
      return false;
      }
  }
  
  /**
   * Leave a room
   * @return {boolean} Success indicator
   */
  leaveRoom() {
      try {
        console.log('[RtcClient] Leaving room');
        this.isInRoom = false;
      this._fireEvent('roomLeft', { success: true });
      return true;
      } catch (error) {
      console.error('[RtcClient] Error leaving room:', error);
      return false;
    }
  }
  
  /**
   * Start a conversation
   * @param {Object} options - Conversation options
   * @return {boolean} Success indicator
   */
  startConversation(options) {
    try {
      console.log('[RtcClient] Starting conversation with options:', options);
      this.isConversationActive = true;
      this.currentTaskId = `task_${Date.now()}`;
      this._fireEvent('conversationStarted', { success: true, taskId: this.currentTaskId });
      
      // If welcome message is provided, simulate a subtitle
      if (options && options.welcomeMessage) {
        this._simulateSubtitle(options.welcomeMessage, true);
      }
      
      return this.currentTaskId;
    } catch (error) {
      console.error('[RtcClient] Error starting conversation:', error);
      return null;
    }
  }
  
  /**
   * Stop a conversation
   * @return {boolean} Success indicator
   */
  stopConversation() {
    try {
      console.log('[RtcClient] Stopping conversation');
      this.isConversationActive = false;
      this.currentTaskId = null;
      this._fireEvent('conversationStopped', { success: true });
      return true;
    } catch (error) {
      console.error('[RtcClient] Error stopping conversation:', error);
      return false;
    }
  }
  
  /**
   * Send a message
   * @param {string} message - Message text
   * @return {boolean} Success indicator
   */
  sendMessage(message) {
    try {
      console.log('[RtcClient] Sending message:', message);
      
      // Simulate AI response
      setTimeout(() => {
        this._fireEvent('aiThinking', { isThinking: true });
        
        setTimeout(() => {
          this._fireEvent('aiSpeaking', { isSpeaking: true });
          
          // Simulate streaming response
          const responses = [
            'Hello, ',
            'Hello, I am ',
            'Hello, I am an AI assistant, ',
            'Hello, I am an AI assistant, how can I help you today?'
          ];
          
          responses.forEach((text, index) => {
            setTimeout(() => {
              this._simulateSubtitle(text, index === responses.length - 1);
            }, 300 * index);
          });
          
          // Finish speaking after last response
          setTimeout(() => {
            this._fireEvent('aiFinished', { isFinished: true });
          }, 300 * responses.length);
        }, 1000);
      }, 500);
      
      return true;
      } catch (error) {
      console.error('[RtcClient] Error sending message:', error);
      return false;
      }
  }
  
  /**
   * Simulate a subtitle event
   * @private
   * @param {string} text - Subtitle text
   * @param {boolean} isFinal - Whether this is the final version
   */
  _simulateSubtitle(text, isFinal) {
    const subtitle = {
      text: text,
      isComplete: isFinal,
      userId: 'BotName001',
      timestamp: Date.now()
    };
    
    this._fireEvent('onSubtitle', subtitle);
  }
  
  /**
   * Start audio capture
   * @param {string} deviceId - Device ID
   * @return {boolean} Success indicator
   */
  startAudioCapture(deviceId) {
    try {
      console.log('[RtcClient] Starting audio capture with device:', deviceId);
      this._fireEvent('audioStatusChanged', { isCapturing: true });
      return true;
    } catch (error) {
      console.error('[RtcClient] Error starting audio capture:', error);
      return false;
    }
  }
  
  /**
   * Stop audio capture
   * @return {boolean} Success indicator
   */
  stopAudioCapture() {
      try {
        console.log('[RtcClient] Stopping audio capture');
      this._fireEvent('audioStatusChanged', { isCapturing: false });
      return true;
    } catch (error) {
      console.error('[RtcClient] Error stopping audio capture:', error);
      return false;
  }
}

/**
   * Get audio input devices
   * @return {Array} List of devices
   */
  getAudioInputDevices() {
    return [
      { deviceId: 'default', label: 'Default Microphone' },
      { deviceId: 'microphone1', label: 'Built-in Microphone' }
    ];
  }
  
  /**
   * Get audio output devices
   * @return {Array} List of devices
   */
  getAudioOutputDevices() {
    return [
      { deviceId: 'default', label: 'Default Speaker' },
      { deviceId: 'speaker1', label: 'Built-in Speaker' }
    ];
  }
  
  /**
   * Register event callbacks
   * @param {Object} callbacks - Callback functions
   */
  registerEventCallbacks(callbacks) {
    console.log('[RtcClient] Registering event callbacks');
    this.callbacks = callbacks || {};
  }
  
  /**
   * Register an event handler
   * @param {string} event - Event name
   * @param {Function} callback - Callback function
   */
  on(event, callback) {
    console.log(`[RtcClient] Registering handler for event: ${event}`);
    this.eventHandlers[event] = callback;
  }
  
  /**
   * Fire an event to registered handlers
   * @private
   * @param {string} eventName - Event name
   * @param {Object} data - Event data
   */
  _fireEvent(eventName, data) {
    try {
      console.log(`[RtcClient] Firing event: ${eventName}`, data);
      const handler = this.eventHandlers[eventName];
      if (handler) {
        handler(data);
      }
    } catch (error) {
      console.error(`[RtcClient] Error firing event ${eventName}:`, error);
    }
  }
  
  /**
   * Test AI subtitle
   * @param {string} text - Subtitle text
   * @param {boolean} isFinal - Whether this is the final version
   * @return {boolean} Success indicator
   */
  testAISubtitle(text, isFinal) {
    try {
      console.log(`[RtcClient] Testing AI subtitle: ${text}, final: ${isFinal}`);
      this._simulateSubtitle(text, isFinal);
      return true;
    } catch (error) {
      console.error('[RtcClient] Error testing AI subtitle:', error);
      return false;
    }
  }
  
  /**
   * Dispose resources
   */
  dispose() {
    console.log('[RtcClient] Disposing resources');
    this.eventHandlers = {};
    this.callbacks = {};
    this.rtcEngine = null;
    this.isInitialized = false;
    this.isInRoom = false;
    this.isConversationActive = false;
  }
}

// Create global instance
window.RTCAIGCPlugin = {
  createClient: function() {
    return new RtcClient();
  }
}; 