import 'dart:async';
import 'dart:html' as html;
import 'dart:js';
import 'dart:js_util';

import 'package:flutter/services.dart';
import 'package:flutter_web_plugins/flutter_web_plugins.dart';
import 'package:rtc_aigc_plugin/rtc_aigc_plugin.dart';
import 'package:rtc_aigc_plugin/src/client/aigc_client.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'package:rtc_aigc_plugin/src/services/service_manager.dart';
import 'package:rtc_aigc_plugin/src/utils/web_utils.dart';

/// Web implementation of the RtcAigcPlugin.
class RtcAigcPluginWeb {
  static void registerWith(Registrar registrar) {
    final channel = MethodChannel(
      'rtc_aigc_plugin',
      const StandardMethodCodec(),
      registrar,
    );

    final pluginInstance = RtcAigcPluginWeb();
    channel.setMethodCallHandler(pluginInstance.handleMethodCall);
  }

  /// Service manager
  ServiceManager? _serviceManager;

  /// Flag to track initialization state
  bool _isInitialized = false;

  /// Flag to track conversation state
  bool _isConversationActive = false;

  Completer<bool>? _sdkLoadingCompleter;

  /// Handles method calls over the method channel.
  Future<dynamic> handleMethodCall(MethodCall call) async {
    print('Received method call: ${call.method}');
    switch (call.method) {
      case 'initialize':
        return _initialize(call.arguments);
      case 'dispose':
        return _dispose();
      case 'startConversation':
        return _startConversation(call.arguments);
      case 'stopConversation':
        return _stopConversation();
      case 'sendTextMessage':
        return _sendTextMessage(call.arguments);
      default:
        throw PlatformException(
          code: 'Unimplemented',
          details: 'rtc_aigc_plugin for web doesn\'t implement \'${call.method}\'',
        );
    }
  }

  /// Internal initialize method
  Future<bool> _initialize(dynamic arguments) async {
    try {
      print('Initializing RTC AIGC plugin for web');
      
      // Parse configuration parameters
      final Map<String, dynamic> args = Map<String, dynamic>.from(arguments);
      
      // Load SDK if not already loaded
      if (_sdkLoadingCompleter == null) {
        _sdkLoadingCompleter = Completer<bool>();
        WebUtils.waitForSdkLoaded().then((_) {
          _sdkLoadingCompleter!.complete(true);
        }).catchError((error) {
          print('Error loading SDK: $error');
          _sdkLoadingCompleter!.complete(false);
        });
      }

      final sdkLoaded = await _sdkLoadingCompleter!.future;
      if (!sdkLoaded) {
        print('SDK loading failed');
        return false;
      }
      
      // Create ASR config
      final asrConfig = AsrConfig(
        appId: args['asrConfig']['appId'] ?? '',
        cluster: args['asrConfig']['cluster'],
        wsEndpoint: args['asrConfig']['wsEndpoint'],
      );

      // Create TTS config
      final ttsConfig = TtsConfig(
        appId: args['ttsConfig']['appId'] ?? '',
        voiceType: args['ttsConfig']['voiceType'],
        cluster: args['ttsConfig']['cluster'],
        ignoreBracketText: args['ttsConfig']['ignoreBracketText'],
      );
      
      // Create LLM config
      final llmConfig = LlmConfig(
        appId: args['llmConfig']['appId'] ?? '',
        modelName: args['llmConfig']['modelName'],
        modelVersion: args['llmConfig']['modelVersion'],
        systemMessages: args['llmConfig']['systemMessages'] != null ? 
                        List<String>.from(args['llmConfig']['systemMessages']) : null,
        welcomeSpeech: args['llmConfig']['welcomeSpeech'],
      );
      
      // Create callbacks that use the global static methods
      final onStateChange = (String state, String? message) {
        print('State change: $state, $message');
        RtcAigcPlugin.handleStateChange(state, message);
      };

      final onMessage = (String text, bool isUser) {
        print('Message received: $text (isUser: $isUser)');
        RtcAigcPlugin.handleMessage(text, isUser);
      };

      final onAudioStatusChange = (bool isPlaying) {
        print('Audio status changed: $isPlaying');
        RtcAigcPlugin.handleAudioStatusChange(isPlaying);
      };
      
      // Call the new initialize method
      return initialize(
        appId: args['appId'] ?? '',
        roomId: args['roomId'] ?? '',
        userId: args['userId'] ?? '',
        token: args['token'] ?? '',
        serverUrl: args['serverUrl'],
        asrConfig: asrConfig,
        ttsConfig: ttsConfig,
        llmConfig: llmConfig,
        onStateChange: onStateChange,
        onMessage: onMessage,
        onAudioStatusChange: onAudioStatusChange,
      );
    } catch (e, s) {
      print('Error initializing plugin: $e');
      print('Stack trace: $s');
      return false;
    }
  }

  /// Initialize the plugin
  Future<bool> initialize({
    required String appId,
    required String roomId,
    required String userId,
    required String token,
    String? serverUrl,
    AsrConfig? asrConfig,
    TtsConfig? ttsConfig,
    LlmConfig? llmConfig,
    Function(String, String?)? onStateChange,
    Function(String, bool)? onMessage,
    Function(bool)? onAudioStatusChange,
  }) async {
    try {
      if (_isInitialized) {
        await _dispose();
      }

      // 创建RTC配置
      final rtcConfig = RtcConfig(
        appId: appId,
        roomId: roomId,
        userId: userId,
        token: token,
      );

      // 创建ASR配置
      final asrConfigObj = asrConfig ?? AsrConfig(
        appId: appId,
      );

      // 创建TTS配置
      final ttsConfigObj = ttsConfig ?? TtsConfig(
        appId: appId,
      );
      
      // 创建LLM配置
      final llmConfigObj = llmConfig ?? LlmConfig(
        appId: appId,
        modelName: 'Doubao-pro-32k',
      );

      // 创建AIGC RTC配置
      final aigcRtcConfig = AigcRtcConfig(
        appId: appId,
        rtcConfig: rtcConfig,
        asrConfig: asrConfigObj,
        ttsConfig: ttsConfigObj,
        llmConfig: llmConfigObj,
        serverUrl: serverUrl,
      );

      // 创建服务管理器
      _serviceManager = ServiceManager(
        config: aigcRtcConfig,
        onStateChange: onStateChange,
        onMessage: onMessage,
        onAudioStatusChange: onAudioStatusChange,
      );

      // 初始化服务
      final success = await _serviceManager!.initialize();
      _isInitialized = success;
      return success;
    } catch (e) {
      print('Error initializing plugin: $e');
      return false;
    }
  }

  /// Dispose the plugin
  Future<bool> _dispose() async {
    try {
      if (_serviceManager != null) {
        _serviceManager!.dispose();
      }
      _serviceManager = null;
      _isInitialized = false;
      _isConversationActive = false;
      return true;
    } catch (e) {
      print('Error disposing plugin: $e');
      return false;
    }
  }

  Future<bool> _startConversation(dynamic arguments) async {
    try {
      if (_serviceManager == null) {
        print('Service manager is null, cannot start conversation');
        return false;
      }

      final Map<String, dynamic> args = Map<String, dynamic>.from(arguments);
      final welcomeMessage = args['welcomeMessage'] as String?;
      
      return await _serviceManager!.startConversation(welcomeMessage: welcomeMessage);
    } catch (e) {
      print('Error starting conversation: $e');
      return false;
    }
  }

  Future<bool> _stopConversation() async {
    try {
      if (_serviceManager == null) {
        return false;
      }
      
      return await _serviceManager!.stopConversation();
    } catch (e) {
      print('Error stopping conversation: $e');
      return false;
    }
  }

  Future<bool> _sendTextMessage(dynamic arguments) async {
    try {
      if (_serviceManager == null) {
        return false;
      }
      
      final message = arguments as String;
      return await _serviceManager!.sendTextMessage(message);
    } catch (e) {
      print('Error sending message: $e');
      return false;
    }
  }
}
