import 'dart:async';

import 'package:flutter_web_plugins/flutter_web_plugins.dart';
import 'package:rtc_aigc_plugin/rtc_aigc_plugin_web.dart';

/// 为保证web平台正确注册插件
class RtcAigcPlugin {
  /// 注册插件
  static void registerWith(Registrar registrar) {
    RtcAigcPluginWeb.registerWith(registrar);
  }
} 