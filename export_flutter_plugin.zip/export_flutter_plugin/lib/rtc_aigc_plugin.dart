// 导出web实现以确保正确注册
export 'rtc_aigc_plugin_web.dart';

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_web_plugins/flutter_web_plugins.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';

/// 全局回调函数
void Function(String state, String? message)? _onStateChange;
void Function(String text, bool isUser)? _onMessage;
void Function(bool isPlaying)? _onAudioStatusChange;

/// RTC AIGC Plugin for real-time voice conversations with AI
class RtcAigcPlugin {
  static const MethodChannel _channel = MethodChannel('rtc_aigc_plugin');

  /// Factory constructor to enforce singleton instance of the plugin
  factory RtcAigcPlugin() => _instance;

  /// Private constructor
  RtcAigcPlugin._();

  /// Singleton instance
  static final RtcAigcPlugin _instance = RtcAigcPlugin._();

  /// Register this plugin
  static void registerWith(Registrar registrar) {
    if (kIsWeb) {
      // Web注册逻辑由web实现提供
    }
  }

  /// Initialize the plugin
  static Future<bool> initialize({
    required String appId,
    required String roomId,
    required String userId,
    required String token,
    String? serverUrl,
    String? websocketUrl,
    AsrConfig? asrConfig,
    TtsConfig? ttsConfig,
    LlmConfig? llmConfig,
    void Function(String state, String? message)? onStateChange,
    void Function(String text, bool isUser)? onMessage,
    void Function(bool isPlaying)? onAudioStatusChange,
  }) async {
    // 保存回调
    _onStateChange = onStateChange;
    _onMessage = onMessage;
    _onAudioStatusChange = onAudioStatusChange;

    final Map<String, dynamic> args = {
      'appId': appId,
      'roomId': roomId,
      'userId': userId,
      'token': token,
      'serverUrl': serverUrl ?? '',
      'websocketUrl': websocketUrl ?? '',
      'asrConfig': asrConfig?.toMap() ?? {},
      'ttsConfig': ttsConfig?.toMap() ?? {},
      'llmConfig': llmConfig?.toMap() ?? {},
      'hasStateCallback': onStateChange != null,
      'hasMessageCallback': onMessage != null,
      'hasAudioStatusCallback': onAudioStatusChange != null,
      'useHttp': serverUrl != null && serverUrl.isNotEmpty,
    };

    try {
      return await _channel.invokeMethod('initialize', args);
    } catch (e) {
      print('Error initializing plugin: $e');
      if (onStateChange != null) {
        onStateChange('error', 'Initialization failed: $e');
      }
      return false;
    }
  }

  /// Start a conversation with the AI
  static Future<bool> startConversation({
    String? welcomeMessage,
  }) async {
    try {
      final Map<String, dynamic> args = {
        'welcomeMessage': welcomeMessage,
      };
      return await _channel.invokeMethod('startConversation', args);
    } catch (e) {
      print('Error starting conversation: $e');
      if (_onStateChange != null) {
        _onStateChange!('error', 'Failed to start conversation: $e');
      }
      return false;
    }
  }

  /// Stop the current conversation
  static Future<bool> stopConversation() async {
    try {
      return await _channel.invokeMethod('stopConversation');
    } catch (e) {
      print('Error stopping conversation: $e');
      if (_onStateChange != null) {
        _onStateChange!('error', 'Failed to stop conversation: $e');
      }
      return false;
    }
  }

  /// Send a text message to the AI
  static Future<bool> sendTextMessage(String message) async {
    try {
      return await _channel.invokeMethod('sendTextMessage', message);
    } catch (e) {
      print('Error sending message: $e');
      if (_onStateChange != null) {
        _onStateChange!('error', 'Failed to send message: $e');
      }
      return false;
    }
  }

  /// Dispose the plugin and release all resources
  static Future<bool> dispose() async {
    try {
      final result = await _channel.invokeMethod('dispose');
      _onStateChange = null;
      _onMessage = null;
      _onAudioStatusChange = null;
      return result;
    } catch (e) {
      print('Error disposing plugin: $e');
      return false;
    }
  }

  /// Called from native code when state changes
  static void handleStateChange(String state, String? message) {
    if (_onStateChange != null) {
      _onStateChange!(state, message);
    }
  }

  /// Called from native code when a message is received
  static void handleMessage(String text, bool isUser) {
    if (_onMessage != null) {
      _onMessage!(text, isUser);
    }
  }

  /// Called from native code when audio status changes
  static void handleAudioStatusChange(bool isPlaying) {
    if (_onAudioStatusChange != null) {
      _onAudioStatusChange!(isPlaying);
    }
  }
}
