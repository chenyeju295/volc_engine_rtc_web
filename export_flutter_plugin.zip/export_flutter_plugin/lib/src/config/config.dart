import 'dart:math';

/// ASR (Automatic Speech Recognition) configuration
class AsrConfig {
  /// Application ID for ASR
  final String appId;
  
  /// Cluster for ASR service
  final String? cluster;
  
  /// WebSocket endpoint for ASR service
  final String? wsEndpoint;
  
  /// ASR configuration
  const AsrConfig({
    required this.appId,
    this.cluster,
    this.wsEndpoint,
  });
  
  /// Convert configuration to map
  Map<String, dynamic> toMap() {
    return {
      'appId': appId,
      if (cluster != null) 'cluster': cluster,
      if (wsEndpoint != null) 'wsEndpoint': wsEndpoint,
    };
  }
  
  /// Create from map
  factory AsrConfig.fromMap(Map<String, dynamic> map) {
    return AsrConfig(
      appId: map['appId'] ?? '',
      cluster: map['cluster'],
      wsEndpoint: map['wsEndpoint'],
    );
  }
}

/// TTS (Text-to-Speech) configuration
class TtsConfig {
  /// Application ID for TTS
  final String appId;
  
  /// Voice type for TTS (e.g., male, female)
  final String? voiceType;
  
  /// Cluster for TTS service
  final String? cluster;
  
  /// Whether to ignore text in brackets
  final bool? ignoreBracketText;
  
  /// TTS configuration
  const TtsConfig({
    required this.appId,
    this.voiceType,
    this.cluster,
    this.ignoreBracketText,
  });
  
  /// Convert configuration to map
  Map<String, dynamic> toMap() {
    return {
      'appId': appId,
      if (voiceType != null) 'voiceType': voiceType,
      if (cluster != null) 'cluster': cluster,
      if (ignoreBracketText != null) 'ignoreBracketText': ignoreBracketText,
    };
  }
  
  /// Create from map
  factory TtsConfig.fromMap(Map<String, dynamic> map) {
    return TtsConfig(
      appId: map['appId'] ?? '',
      voiceType: map['voiceType'],
      cluster: map['cluster'],
      ignoreBracketText: map['ignoreBracketText'],
    );
  }
}

/// LLM (Large Language Model) configuration
class LlmConfig {
  /// Application ID for LLM
  final String appId;
  
  /// Model name
  final String? modelName;
  
  /// Model version
  final String? modelVersion;
  
  /// Mode (e.g., chat, completion)
  final String? mode;
  
  /// Host for LLM API
  final String? host;
  
  /// Region for LLM API
  final String? region;
  
  /// Maximum tokens to generate
  final int? maxTokens;
  
  /// Minimum tokens to generate
  final int? minTokens;
  
  /// Temperature for sampling
  final double? temperature;
  
  /// Top-p for sampling
  final double? topP;
  
  /// Top-k for sampling
  final int? topK;
  
  /// Maximum prompt tokens
  final int? maxPromptTokens;
  
  /// System messages for chat
  final List<String>? systemMessages;
  
  /// User messages for chat
  final List<String>? userMessages;
  
  /// History length to consider
  final int? historyLength;
  
  /// Welcome speech
  final String? welcomeSpeech;
  
  /// Endpoint ID
  final String? endPointId;
  
  /// Bot ID
  final String? botId;
  
  /// LLM configuration
  const LlmConfig({
    required this.appId,
    this.modelName = 'Doubao-pro-32k',
    this.modelVersion = '1.0',
    this.mode = 'chat',
    this.host,
    this.region,
    this.maxTokens = 1024,
    this.minTokens,
    this.temperature = 0.7,
    this.topP = 0.5,
    this.topK,
    this.maxPromptTokens,
    this.systemMessages,
    this.userMessages,
    this.historyLength = 10,
    this.welcomeSpeech = '您好，我是AI助手，有什么可以帮您的？',
    this.endPointId,
    this.botId,
  });
  
  /// Convert configuration to map
  Map<String, dynamic> toMap() {
    return {
      'appId': appId,
      if (modelName != null) 'modelName': modelName,
      if (modelVersion != null) 'modelVersion': modelVersion,
      if (mode != null) 'mode': mode,
      if (host != null) 'host': host,
      if (region != null) 'region': region,
      if (maxTokens != null) 'maxTokens': maxTokens,
      if (minTokens != null) 'minTokens': minTokens,
      if (temperature != null) 'temperature': temperature,
      if (topP != null) 'topP': topP,
      if (topK != null) 'topK': topK,
      if (maxPromptTokens != null) 'maxPromptTokens': maxPromptTokens,
      if (systemMessages != null) 'systemMessages': systemMessages,
      if (userMessages != null) 'userMessages': userMessages,
      if (historyLength != null) 'historyLength': historyLength,
      if (welcomeSpeech != null) 'welcomeSpeech': welcomeSpeech,
      if (endPointId != null) 'endPointId': endPointId,
      if (botId != null) 'botId': botId,
    };
  }
  
  /// Create from map
  factory LlmConfig.fromMap(Map<String, dynamic> map) {
    return LlmConfig(
      appId: map['appId'] ?? '',
      modelName: map['modelName'] ?? 'Doubao-pro-32k',
      modelVersion: map['modelVersion'] ?? '1.0',
      mode: map['mode'] ?? 'chat',
      host: map['host'],
      region: map['region'],
      maxTokens: map['maxTokens'] ?? 1024,
      minTokens: map['minTokens'],
      temperature: map['temperature'] ?? 0.7,
      topP: map['topP'] ?? 0.5,
      topK: map['topK'],
      maxPromptTokens: map['maxPromptTokens'],
      systemMessages: map['systemMessages'] != null 
          ? List<String>.from(map['systemMessages'])
          : null,
      userMessages: map['userMessages'] != null
          ? List<String>.from(map['userMessages'])
          : null,
      historyLength: map['historyLength'] ?? 10,
      welcomeSpeech: map['welcomeSpeech'] ?? '您好，我是AI助手，有什么可以帮您的？',
      endPointId: map['endPointId'],
      botId: map['botId'],
    );
  }
}

/// Configuration for RTC service
class RtcConfig {
  /// Application ID
  final String appId;

  /// Room ID
  final String roomId;

  /// User ID
  final String userId;

  /// Token
  final String token;

  /// Task ID
  final String? taskId;

  /// Server URL for HTTP API
  final String? serverUrl;
  
  /// RTC configuration for real-time communications
  const RtcConfig({
    required this.appId,
    required this.roomId,
    required this.userId,
    required this.token,
    this.taskId,
    this.serverUrl,
  });

  /// Convert to map
  Map<String, dynamic> toMap() {
    return {
      'appId': appId,
      'roomId': roomId,
      'userId': userId,
      'token': token,
      if (taskId != null) 'taskId': taskId,
      if (serverUrl != null) 'serverUrl': serverUrl,
    };
  }

  /// Create from map
  factory RtcConfig.fromMap(Map<String, dynamic> map) {
    return RtcConfig(
      appId: map['appId'],
      roomId: map['roomId'],
      userId: map['userId'],
      token: map['token'],
      taskId: map['taskId'],
      serverUrl: map['serverUrl'],
    );
  }

  /// Clone with updates
  RtcConfig copyWith({
    String? appId,
    String? roomId,
    String? userId,
    String? token,
    String? taskId,
    String? serverUrl,
  }) {
    return RtcConfig(
      appId: appId ?? this.appId,
      roomId: roomId ?? this.roomId,
      userId: userId ?? this.userId,
      token: token ?? this.token,
      taskId: taskId ?? this.taskId,
      serverUrl: serverUrl ?? this.serverUrl,
    );
  }
}

/// Main configuration for AIGC RTC services
class AigcRtcConfig {
  /// Application ID
  final String appId;

  /// RTC configuration
  final RtcConfig rtcConfig;

  /// ASR configuration
  final AsrConfig asrConfig;

  /// TTS configuration
  final TtsConfig ttsConfig;

  /// LLM configuration
  final LlmConfig llmConfig;

  /// WebSocket URL (可选，仅在使用WebSocket服务时指定)
  final String? websocketUrl;
  
  /// Server URL for HTTP API (推荐使用HTTP服务)
  final String? serverUrl;
  
  /// AIGC RTC configuration
  const AigcRtcConfig({
    required this.appId,
    required this.rtcConfig,
    required this.asrConfig,
    required this.ttsConfig,
    required this.llmConfig,
    this.websocketUrl,
    this.serverUrl,
  });

  /// Convert to map
  Map<String, dynamic> toMap() {
    return {
      'appId': appId,
      'rtcConfig': rtcConfig.toMap(),
      'asrConfig': asrConfig.toMap(),
      'ttsConfig': ttsConfig.toMap(),
      'llmConfig': llmConfig.toMap(),
      if (websocketUrl != null) 'websocketUrl': websocketUrl,
      if (serverUrl != null) 'serverUrl': serverUrl,
    };
  }

  /// Create from map
  factory AigcRtcConfig.fromMap(Map<String, dynamic> map) {
    return AigcRtcConfig(
      appId: map['appId'],
      rtcConfig: RtcConfig.fromMap(map['rtcConfig']),
      asrConfig: AsrConfig.fromMap(map['asrConfig']),
      ttsConfig: TtsConfig.fromMap(map['ttsConfig']),
      llmConfig: LlmConfig.fromMap(map['llmConfig']),
      websocketUrl: map['websocketUrl'],
      serverUrl: map['serverUrl'],
    );
  }

  /// Clone with updates
  AigcRtcConfig copyWith({
    String? appId,
    RtcConfig? rtcConfig,
    AsrConfig? asrConfig,
    TtsConfig? ttsConfig,
    LlmConfig? llmConfig,
    String? websocketUrl,
    String? serverUrl,
  }) {
    return AigcRtcConfig(
      appId: appId ?? this.appId,
      rtcConfig: rtcConfig ?? this.rtcConfig,
      asrConfig: asrConfig ?? this.asrConfig,
      ttsConfig: ttsConfig ?? this.ttsConfig,
      llmConfig: llmConfig ?? this.llmConfig,
      websocketUrl: websocketUrl ?? this.websocketUrl,
      serverUrl: serverUrl ?? this.serverUrl,
    );
  }
}

/// Server authentication configuration
class ServerAuthConfig {
  /// Access key for server authentication
  final String accessKey;
  
 /// Secret key for server authentication
  final String secretKey;
  
  /// Session token (required for sub-accounts)
  final String? sessionToken;

  /// Server authentication configuration
  const ServerAuthConfig({
    required this.accessKey,
    required this.secretKey,
    this.sessionToken,
  });
} 