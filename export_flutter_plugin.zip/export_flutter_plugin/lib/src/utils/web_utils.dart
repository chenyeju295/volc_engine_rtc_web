import 'dart:async';
import 'dart:html' as html;
import 'dart:js' as js;
import 'dart:js_util' as js_util;
import 'package:flutter/foundation.dart';

/// Web utilities for handling JavaScript interop and resource loading
class WebUtils {
  /// Whether scripts are being loaded
  static bool _areScriptsLoading = false;

  /// Script loading completion
  static Completer<bool>? _loadingCompleter;

  /// SDKs to load
  static final List<String> _sdks = [
    'https://lf-unpkg.volccdn.com/obj/vcloudfe/sdk/@volcengine/rtc/4.66.1/1741254642340/volengine_Web_4.66.1.js',
  ];

  /// Local scripts to load
  static final List<String> _scripts = [
    'assets/packages/rtc_aigc_plugin/web/rtc_interop.js',
  ];

  /// Wait for SDK to load
  static Future<void> waitForSdkLoaded() async {
    final completer = Completer<void>();
    
    try {
      // Check if RTC objects already exist
      if (!js.context.hasProperty('VERTC') && !js.context.hasProperty('VERTCWeb')) {
        debugPrint('VERTC SDK not loaded, loading scripts...');
        
        // Add event listener for script load
        await _loadVERTCScripts(completer);
      } else {
        debugPrint('VERTC SDK already loaded');
        completer.complete();
      }
    } catch (e) {
      debugPrint('Error while loading SDK: $e');
      completer.completeError(e);
    }
    
    return completer.future;
  }
  
  /// Load VERTC scripts
  static Future<void> _loadVERTCScripts(Completer<void> completer) async {
    try {
      // First load the SDK
      for (final sdk in _sdks) {
        await _loadScript(sdk);
      }

      // Wait a moment to ensure SDK is initialized
      await Future.delayed(const Duration(milliseconds: 500));

      // Verify SDK objects exist
      if (!js.context.hasProperty('VERTC') && !js.context.hasProperty('VERTCWeb')) {
        throw Exception('Volcano Engine RTC SDK not loaded properly - VERTC/VERTCWeb object not found');
      }
      debugPrint('Volcano Engine RTC SDK loaded successfully');

      // Then load local scripts
      for (final script in _scripts) {
        await _loadScript(script);
      }

      // Wait a moment for the interop scripts to initialize
      await Future.delayed(const Duration(milliseconds: 200));
      
      completer.complete();
    } catch (e) {
      debugPrint('Failed to load VERTC scripts: $e');
      completer.completeError(e);
    }
  }

  /// Safely call a JavaScript method, handling null objects and exceptions
  static dynamic safeJsCall(dynamic jsObject, String method, [List<dynamic>? args]) {
    if (jsObject == null) {
      debugPrint('Cannot call $method: JavaScript object is null');
      return null;
    }

    try {
      // 检查是否存在该方法（仅对js.JsObject类型有效）
      if (jsObject is js.JsObject && !jsObject.hasProperty(method)) {
        debugPrint('Warning: JavaScript object does not have method: $method');
        return null;
      }
      
      // 调用方法
      if (args != null) {
        return jsObject.callMethod(method, args);
      } else {
        return jsObject.callMethod(method);
      }
    } catch (e) {
      debugPrint('Error calling $method: $e');
      // 如果发生错误，尝试记录更多诊断信息
      if (jsObject is js.JsObject) {
        try {
          final properties = js.context['Object'].callMethod('keys', [jsObject]);
          debugPrint('Available properties/methods: $properties');
        } catch (e2) {
          debugPrint('Could not enumerate properties: $e2');
        }
      }
      return null;
    }
  }
  
  /// Call a JavaScript method that returns a Promise
  static dynamic callMethod(dynamic jsObject, String method, [List<dynamic>? args]) {
    if (jsObject == null) {
      throw Exception('JavaScript object is null, cannot call $method');
    }
    
    try {
      // 检查是否存在该方法（仅对js.JsObject类型有效）
      if (jsObject is js.JsObject && !jsObject.hasProperty(method)) {
        throw Exception('JavaScript object does not have method: $method');
      }
      
      if (args != null) {
        return js_util.callMethod(jsObject, method, args);
      } else {
        return js_util.callMethod(jsObject, method, []);
      }
    } catch (e) {
      debugPrint('Error calling $method: $e');
      // 如果发生错误，尝试记录更多诊断信息
      if (jsObject is js.JsObject) {
        try {
          final properties = js.context['Object'].callMethod('keys', [jsObject]);
          debugPrint('Available properties/methods: $properties');
        } catch (e2) {
          debugPrint('Could not enumerate properties: $e2');
        }
      }
      throw Exception('Failed to call $method: $e');
    }
  }
  
  /// Convert a JavaScript Promise to a Dart Future
  static Future<T> promiseToFuture<T>(dynamic jsPromise) {
    if (jsPromise == null) {
      throw Exception('Promise is null');
    }
    
    try {
      return js_util.promiseToFuture<T>(jsPromise);
    } catch (e) {
      debugPrint('Error converting Promise to Future: $e');
      throw e;
    }
  }

  /// Check if a JavaScript object exists
  static bool jsObjectExists(String objectName) {
    try {
      return js.context.hasProperty(objectName);
    } catch (e) {
      debugPrint('Error checking if object exists: $e');
      return false;
    }
  }

  /// Check if scripts are already loaded
  static bool _areScriptsAlreadyLoaded() {
    // Check if RTC object already exists (must check both old and new SDK object names)
    if (js.context.hasProperty('VERTC') || js.context.hasProperty('VERTCWeb')) {
      debugPrint('Volcano Engine RTC SDK already loaded');
      return true;
    }

    // Check if script tags already exist
    final scripts = html.document.querySelectorAll('script');
    bool sdksLoaded = true;
    bool localScriptsLoaded = true;

    // Check if SDKs are loaded
    for (final sdk in _sdks) {
      bool found = false;
      for (final script in scripts) {
        final src = script.getAttribute('src') ?? '';
        if (src.contains(_getScriptBaseName(sdk))) {
          found = true;
          break;
        }
      }
      if (!found) {
        sdksLoaded = false;
        break;
      }
    }

    // Check if local scripts are loaded
    for (final scriptPath in _scripts) {
      bool found = false;
      for (final script in scripts) {
        final src = script.getAttribute('src') ?? '';
        if (src.contains(_getScriptBaseName(scriptPath))) {
          found = true;
          break;
        }
      }
      if (!found) {
        localScriptsLoaded = false;
        break;
      }
    }

    return sdksLoaded && localScriptsLoaded;
  }

  /// Check if SDK is loaded
  static bool isSdkLoaded() {
    if (js.context.hasProperty('VERTC') || js.context.hasProperty('VERTCWeb')) {
      return true;
    }
    return false;
  }

  /// Check if VERTC objects are loaded
  static bool isVertcLoaded() {
    return js.context.hasProperty('VERTC');
  }

  /// Get the base name of a script path
  static String _getScriptBaseName(String path) {
    final parts = path.split('/');
    return parts.last;
  }

  /// Load a script and return a future that completes when the script is loaded
  static Future<void> _loadScript(String url) async {
    // Check if already loaded
    final scripts = html.document.querySelectorAll('script');
    for (final script in scripts) {
      final src = script.getAttribute('src') ?? '';
      if (src.contains(_getScriptBaseName(url))) {
        debugPrint('Script already loaded: $url');
        return;
      }
    }

    debugPrint('Loading script: $url');
    final completer = Completer<void>();
    
    final scriptElement = html.ScriptElement();
    scriptElement.type = 'text/javascript';
    scriptElement.src = url;
    
    scriptElement.onLoad.listen((_) {
      debugPrint('Script loaded: $url');
      completer.complete();
    });
    
    scriptElement.onError.listen((event) {
      debugPrint('Failed to load script: $url');
      completer.completeError('Failed to load script: $url');
    });
    
    html.document.head!.append(scriptElement);
    return completer.future;
  }

  /// Debug print wrapper for logging
  static void debugPrint(String message) {
    if (kDebugMode) {
      print('[WebUtils] $message');
    }
  }
} 