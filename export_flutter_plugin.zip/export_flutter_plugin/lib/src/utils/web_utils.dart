import 'dart:async';
import 'dart:html' as html;
import 'dart:js';
import 'package:flutter/foundation.dart';

/// Web utilities for handling JavaScript interop and resource loading
class WebUtils {
  /// Whether scripts are being loaded
  static bool _areScriptsLoading = false;

  /// Script loading completion
  static Completer<bool>? _loadingCompleter;

  /// SDKs to load
  static final List<String> _sdks = [
    'https://lf-unpkg.volccdn.com/obj/vcloudfe/sdk/@volcengine/rtc/4.66.1/1741254642340/volengine_Web_4.66.1.js',
  ];

  /// Local scripts to load
  static final List<String> _scripts = [
    'assets/packages/rtc_aigc_plugin/web/rtc_interop.js',
  ];

  /// Wait for SDK and interop scripts to load
  static Future<void> waitForSdkLoaded() async {
    if (_loadingCompleter != null) {
      await _loadingCompleter!.future;
      return;
    }

    // Check if scripts are already loaded
    if (_areScriptsAlreadyLoaded()) {
      debugPrint('SDK already loaded');
      return;
    }

    _loadingCompleter = Completer<bool>();
    _areScriptsLoading = true;

    try {
      debugPrint('Loading volengine SDK and scripts...');
      
      // First load the SDK
      for (final sdk in _sdks) {
        await _loadScript(sdk);
      }

      // Wait a moment to ensure SDK is initialized
      await Future.delayed(const Duration(milliseconds: 500));

      // Verify SDK objects exist
      if (!context.hasProperty('VERTC') && !context.hasProperty('VERTCWeb')) {
        throw Exception('Volcano Engine RTC SDK not loaded properly - VERTC/VERTCWeb object not found');
      }
      debugPrint('Volcano Engine RTC SDK loaded successfully');

      // Then load local scripts
      for (final script in _scripts) {
        await _loadScript(script);
      }

      // Wait a moment for the interop scripts to initialize
      await Future.delayed(const Duration(milliseconds: 200));

      // Use try/catch for checking objects to avoid errors
      bool rtcClientExists = false;
      bool asrClientExists = false;
      bool ttsClientExists = false;
      
      try {
        rtcClientExists = checkJsObject('RtcClient');
        asrClientExists = checkJsObject('AsrClient');
        ttsClientExists = checkJsObject('TtsClient');
        debugPrint('JS Objects: RtcClient=$rtcClientExists, AsrClient=$asrClientExists, TtsClient=$ttsClientExists');
      } catch (e) {
        debugPrint('Error checking JS objects: $e');
      }

      _areScriptsLoading = false;
      _loadingCompleter!.complete(true);
      debugPrint('All scripts loaded successfully');
    } catch (e) {
      _areScriptsLoading = false;
      _loadingCompleter!.completeError(e);
      debugPrint('Failed to load scripts: $e');
      throw Exception('Failed to load scripts: $e');
    }
  }

  /// Check if a JavaScript object exists in context
  static bool checkJsObject(String objectName) {
    try {
      return context.hasProperty(objectName);
    } catch (e) {
      debugPrint('Error checking object $objectName: $e');
      return false;
    }
  }

  /// Safely call a JavaScript method, handling null objects and exceptions
  static dynamic safeJsCall(dynamic jsObject, String method, [List<dynamic>? args]) {
    if (jsObject == null) {
      debugPrint('Cannot call $method: JavaScript object is null');
      return null;
    }

    try {
      if (args != null) {
        return jsObject.callMethod(method, args);
      } else {
        return jsObject.callMethod(method);
      }
    } catch (e) {
      debugPrint('Error calling $method: $e');
      return null;
    }
  }

  /// Check if scripts are already loaded
  static bool _areScriptsAlreadyLoaded() {
    // Check if RTC object already exists (must check both old and new SDK object names)
    if (context.hasProperty('VERTC') || context.hasProperty('VERTCWeb')) {
      debugPrint('Volcano Engine RTC SDK already loaded');
      return true;
    }

    // Check if script tags already exist
    final scripts = html.document.querySelectorAll('script');
    bool sdksLoaded = true;
    bool localScriptsLoaded = true;

    // Check if SDKs are loaded
    for (final sdk in _sdks) {
      bool found = false;
      for (final script in scripts) {
        final src = script.getAttribute('src') ?? '';
        if (src.contains(_getScriptBaseName(sdk))) {
          found = true;
          break;
        }
      }
      if (!found) {
        sdksLoaded = false;
        break;
      }
    }

    // Check if local scripts are loaded
    for (final scriptPath in _scripts) {
      bool found = false;
      for (final script in scripts) {
        final src = script.getAttribute('src') ?? '';
        if (src.contains(_getScriptBaseName(scriptPath))) {
          found = true;
          break;
        }
      }
      if (!found) {
        localScriptsLoaded = false;
        break;
      }
    }

    return sdksLoaded && localScriptsLoaded;
  }

  /// Check if SDK is loaded
  static bool isSdkLoaded() {
    // Check if RTC object already exists (must check both old and new SDK object names)
    return context.hasProperty('VERTC') || context.hasProperty('VERTCWeb');
  }

  /// Get the base name of a script path
  static String _getScriptBaseName(String path) {
    final parts = path.split('/');
    return parts.last;
  }

  /// Load a script and return a future that completes when the script is loaded
  static Future<void> _loadScript(String url) async {
    // Check if already loaded
    final scripts = html.document.querySelectorAll('script');
    for (final script in scripts) {
      final src = script.getAttribute('src') ?? '';
      if (src.contains(_getScriptBaseName(url))) {
        debugPrint('Script already loaded: $url');
        return;
      }
    }

    debugPrint('Loading script: $url');
    final completer = Completer<void>();
    
    final scriptElement = html.ScriptElement();
    scriptElement.type = 'text/javascript';
    scriptElement.src = url;
    
    scriptElement.onLoad.listen((_) {
      debugPrint('Script loaded: $url');
      completer.complete();
    });
    
    scriptElement.onError.listen((event) {
      debugPrint('Failed to load script: $url');
      completer.completeError('Failed to load script: $url');
    });
    
    html.document.head!.append(scriptElement);
    return completer.future;
  }

  /// Debug print wrapper for logging
  static void debugPrint(String message) {
    if (kDebugMode) {
      print('[WebUtils] $message');
    }
  }
} 