import 'dart:async';
import 'dart:js' as js;

import 'package:flutter/foundation.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_conversation_manager.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_device_manager.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_engine_manager.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_event_manager.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_message_handler.dart';
import 'package:rtc_aigc_plugin/src/utils/web_utils.dart';

/// Main service class for RTC operations
class RtcService {
  // Configuration
  final RtcConfig config;

  // Managers
  late final RtcEngineManager _engineManager;
  late final RtcDeviceManager _deviceManager;
  late final RtcEventManager _eventManager;
  late final RtcMessageHandler _messageHandler;
  late final RtcConversationManager _conversationManager;

  // State
  bool _isInitialized = false;
  bool _isDisposed = false;

  // Public streams and getters
  Stream<Map<String, dynamic>?> get subtitleStream =>
      _messageHandler.subtitleStream;
  Stream<Map<String, dynamic>> get stateStream => _eventManager.stateStream;
  Stream<bool> get audioStatusStream => _deviceManager.audioStatusStream;
  Stream<String> get connectionStateStream => _eventManager.connectionStream;
  Stream<bool> get deviceStateStream => _deviceManager.deviceStateStream;
  Stream<Map<String, List<Map<String, String>>>> get deviceChangeStream =>
      _deviceManager.deviceChangeStream;
  Stream<Map<String, dynamic>> get messageHistoryStream =>
      _messageHandler.messageHistoryStream;

  // Add audio devices stream for ServiceManager usage
  Stream<List<dynamic>> get audioDevicesStream =>
      _eventManager.audioDevicesStream;

  /// Constructor
  RtcService({required this.config}) {
    _engineManager = RtcEngineManager(config: config);
    _deviceManager = RtcDeviceManager(config: config);
    _eventManager = RtcEventManager(config: config);
    _messageHandler = RtcMessageHandler(config: config);
    _conversationManager = RtcConversationManager(
      config: config,
      messageHandler: _messageHandler,
      eventManager: _eventManager,
    );

    debugPrint('RtcService created with config: $config');
  }

  /// Initialize the RTC service
  Future<bool> initialize() async {
    if (_isInitialized || _isDisposed) {
      return _isInitialized;
    }

    try {
      debugPrint('Initializing RTC service...');

      // Initialize the engine
      final rtcClient = await _engineManager.initialize();

      if (rtcClient == null) {
        debugPrint('Failed to initialize RTC engine');
        return false;
      }

      // Set the engine for all managers
      _deviceManager.setEngine(rtcClient);
      _eventManager.setEngine(rtcClient);
      _messageHandler.setEngine(rtcClient);

      // Get AIGC client safely
      dynamic aigcClient;
      try {
        // Try to call getAigcClient if available
        if (_engineManager.aigcClient != null) {
          // Access the property directly if available
          aigcClient = _engineManager.aigcClient;
          debugPrint('Got AIGC client from engineManager.aigcClient property');
        } else {
          // Fallback: Create a new AIGC client instance
          debugPrint(
              'No AIGC client available, conversation functionality may be limited');
        }
      } catch (e) {
        debugPrint('Error getting AIGC client: $e');
      }

      // Set the engine for conversation manager
      _conversationManager.setEngine(rtcClient, aigcClient);

      // Register event handlers
      _registerEventHandlers();

      _isInitialized = true;
      debugPrint('RTC service initialized successfully');
      return true;
    } catch (e) {
      debugPrint('Error initializing RTC service: $e');
      return false;
    }
  }

  /// Register event handlers for RTC events
  void _registerEventHandlers() {
    // Add event handlers here
    debugPrint('Registering RTC event handlers');

    // Register handlers for binary messages
    // if (_rtcClient != null) {
    //   WebUtils.safeJsCall(_rtcClient, 'registerMessageCallback',
    //     [js.allowInterop((userId, message) {
    //       _messageHandler.handleBinaryMessage(userId, message);
    //     })]);
    //
    //   debugPrint('Registered message callback handler');
    // }
  }

  /// Join an RTC room
  Future<bool> joinRoom({String? serverUrl}) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint('Cannot join room: RTC service not initialized or disposed');
      return false;
    }

    try {
      debugPrint('Joining RTC room: ${config.roomId}');

      // Update server URL if provided
      final String effectiveServerUrl = serverUrl ?? config.serverUrl ?? '';

      // Join room via engine manager
      final success =
          await _engineManager.joinRoom(serverUrl: effectiveServerUrl);

      if (success) {
        debugPrint('Successfully joined RTC room');
      } else {
        debugPrint('Failed to join RTC room');
      }

      return success;
    } catch (e) {
      debugPrint('Error joining RTC room: $e');
      return false;
    }
  }

  /// Leave the RTC room
  Future<bool> leaveRoom() async {
    if (!_isInitialized || _isDisposed) {
      debugPrint('Cannot leave room: RTC service not initialized or disposed');
      return true; // Already not in a room
    }

    try {
      debugPrint('Leaving RTC room');

      // First stop any active conversation
      if (_conversationManager.isConversationActive) {
        await stopConversation();
      }

      // Leave room via engine manager
      final success = await _engineManager.leaveRoom();

      debugPrint('Left RTC room. Success: $success');
      return success;
    } catch (e) {
      debugPrint('Error leaving RTC room: $e');
      return false;
    }
  }

  /// Start a conversation with the AI
  Future<String?> startConversation({String? welcomeMessage}) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot start conversation: RTC service not initialized or disposed');
      return null;
    }

    try {
      debugPrint('Starting AI conversation');

      // Start conversation via conversation manager
      final result = await _conversationManager.startConversation(
        welcomeMessage: welcomeMessage,
      );

      if (result['success']) {
        debugPrint('AI conversation started. Task ID: ${result['taskId']}');
        return result['taskId'];
      } else {
        debugPrint('Failed to start AI conversation');
        return null;
      }
    } catch (e) {
      debugPrint('Error starting AI conversation: $e');
      return null;
    }
  }

  /// Stop the current AI conversation
  Future<bool> stopConversation() async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot stop conversation: RTC service not initialized or disposed');
      return false;
    }

    try {
      debugPrint('Stopping AI conversation');

      // Stop conversation via conversation manager
      final success = await _conversationManager.stopConversation();

      debugPrint('AI conversation stopped. Success: $success');
      return success;
    } catch (e) {
      debugPrint('Error stopping AI conversation: $e');
      return false;
    }
  }

  /// Interrupt the AI's response
  Future<bool> interruptConversation() async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot interrupt conversation: RTC service not initialized or disposed');
      return false;
    }

    try {
      debugPrint('Interrupting AI conversation');

      // Interrupt conversation via conversation manager
      final success = await _conversationManager.interruptConversation();

      debugPrint('AI conversation interrupted. Success: $success');
      return success;
    } catch (e) {
      debugPrint('Error interrupting AI conversation: $e');
      return false;
    }
  }

  /// Resume audio playback (resolves browser autoplay issues)
  Future<bool> resumeAudioPlayback() async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot resume audio: RTC service not initialized or disposed');
      return false;
    }

    try {
      debugPrint('Resuming audio playback');

      // Resume audio via device manager
      final success = await _deviceManager.resumeAudioPlayback();

      debugPrint('Audio playback resumed. Success: $success');
      return success;
    } catch (e) {
      debugPrint('Error resuming audio playback: $e');
      return false;
    }
  }

  /// Send a text message to the AI
  Future<bool> sendMessage(String message) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot send message: RTC service not initialized or disposed');
      return false;
    }

    if (!_conversationManager.isConversationActive) {
      debugPrint('Cannot send message: No active conversation');
      return false;
    }

    try {
      debugPrint('Sending message to AI: $message');

      // Create user message
      final userMessage = {
        'text': message,
        'userId': config.userId,
        'isFinal': true,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      // Add user message to history
      _messageHandler.addMessageToHistory(userMessage);

      // Send via conversation manager instead of engine manager
      final success = await _conversationManager.sendMessage(message);

      debugPrint('Message sent to AI. Success: $success');
      return success;
    } catch (e) {
      debugPrint('Error sending message to AI: $e');
      return false;
    }
  }

  /// Get audio input devices (microphones)
  Future<List<Map<String, String>>> getAudioInputDevices() async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot get audio input devices: RTC service not initialized or disposed');
      return [];
    }

    try {
      return await _deviceManager.getAudioInputDevices();
    } catch (e) {
      debugPrint('Error getting audio input devices: $e');
      return [];
    }
  }

  /// Get audio output devices (speakers)
  Future<List<Map<String, String>>> getAudioOutputDevices() async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot get audio output devices: RTC service not initialized or disposed');
      return [];
    }

    try {
      return await _deviceManager.getAudioOutputDevices();
    } catch (e) {
      debugPrint('Error getting audio output devices: $e');
      return [];
    }
  }

  /// Set audio capture device (microphone)
  Future<bool> setAudioCaptureDevice(String deviceId) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot set audio capture device: RTC service not initialized or disposed');
      return false;
    }

    try {
      return await _deviceManager.setAudioCaptureDevice(deviceId);
    } catch (e) {
      debugPrint('Error setting audio capture device: $e');
      return false;
    }
  }

  /// Set audio playback device (speaker)
  Future<bool> setAudioPlaybackDevice(String deviceId) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot set audio playback device: RTC service not initialized or disposed');
      return false;
    }

    try {
      return await _deviceManager.setAudioPlaybackDevice(deviceId);
    } catch (e) {
      debugPrint('Error setting audio playback device: $e');
      return false;
    }
  }

  /// Get current audio input device ID
  String? getCurrentAudioInputDeviceId() {
    if (!_isInitialized || _isDisposed) {
      return null;
    }

    return _deviceManager.getCurrentAudioInputDeviceId();
  }

  /// Get current audio output device ID
  String? getCurrentAudioOutputDeviceId() {
    if (!_isInitialized || _isDisposed) {
      return null;
    }

    return _deviceManager.getCurrentAudioOutputDeviceId();
  }

  /// Request microphone access
  Future<bool> requestMicrophoneAccess() async {
    try {
      // This will be implemented by requesting user media
      // For now we just return true as a placeholder
      return true;
    } catch (e) {
      debugPrint('Error requesting microphone access: $e');
      return false;
    }
  }

  /// Request camera access
  Future<bool> requestCameraAccess() async {
    try {
      // This will be implemented by requesting user media
      // For now we just return true as a placeholder
      return true;
    } catch (e) {
      debugPrint('Error requesting camera access: $e');
      return false;
    }
  }

  /// Start audio capture
  Future<bool> startAudioCapture(String? deviceId) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot start audio capture: RTC service not initialized or disposed');
      return false;
    }

    try {
      return await _deviceManager.startAudioCapture(deviceId);
    } catch (e) {
      debugPrint('Error starting audio capture: $e');
      return false;
    }
  }

  /// Stop audio capture
  Future<bool> stopAudioCapture() async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot stop audio capture: RTC service not initialized or disposed');
      return false;
    }

    try {
      return await _deviceManager.stopAudioCapture();
    } catch (e) {
      debugPrint('Error stopping audio capture: $e');
      return false;
    }
  }

  /// Test AI subtitle (for development only)
  Future<bool> testAISubtitle(String text, {bool isFinal = true}) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint(
          'Cannot test AI subtitle: RTC service not initialized or disposed');
      return false;
    }

    try {
      debugPrint('Testing AI subtitle: $text (isFinal: $isFinal)');

      // Use conversation manager's testAISubtitle method
      return await _conversationManager.testAISubtitle(text, isFinal: isFinal);
    } catch (e) {
      debugPrint('Error testing AI subtitle: $e');
      return false;
    }
  }

  /// Get message history
  List<Map<String, dynamic>> getMessageHistory() {
    return _messageHandler.getMessageHistory();
  }

  /// Dispose of resources
  Future<void> dispose() async {
    if (_isDisposed) {
      return;
    }

    _isDisposed = true;
    _isInitialized = false;

    try {
      // Stop any active conversation
      if (_conversationManager.isConversationActive) {
        await stopConversation();
      }

      // Clean up managers
      await _engineManager.dispose();

      debugPrint('RTC service disposed');
    } catch (e) {
      debugPrint('Error disposing RTC service: $e');
    }
  }
}
