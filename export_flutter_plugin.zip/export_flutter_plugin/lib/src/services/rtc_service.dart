import 'dart:async';
import 'dart:html' as html;
import 'dart:js' as js;
import 'dart:typed_data';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import '../client/aigc_client.dart';
import '../config/config.dart';
import '../utils/web_utils.dart';
import 'service_interface.dart';

/// Callback for device state changes
typedef DeviceStateCallback = void Function(bool isAvailable);

/// RTC service for real-time communications
class RtcService implements Service {
  /// Configuration for the RTC service
  final RtcConfig config;

  /// AIGC HTTP Client
  AigcClient? _aigcClient;

  /// JS RTC client
  js.JsObject? _rtcClient;

  /// 当前任务ID
  String? _currentTaskId;

  /// Is microphone active
  bool _isMicrophoneActive = false;

  /// Is camera active
  bool _isCameraActive = false;

  /// Is conversation active
  bool _isConversationActive = false;

  /// Device state stream controller
  final StreamController<bool> _deviceStateController =
      StreamController<bool>.broadcast();

  /// Message stream controller
  final StreamController<String> _messageController =
      StreamController<String>.broadcast();

  /// Connection state stream controller
  final StreamController<String> _connectionStateController =
      StreamController<String>.broadcast();

  /// Stream of device state changes (available/unavailable)
  Stream<bool> get deviceStateStream => _deviceStateController.stream;

  /// Stream of messages
  Stream<String> get messageStream => _messageController.stream;

  /// Stream of connection state changes
  Stream<String> get connectionStateStream => _connectionStateController.stream;

  /// Audio element for playing TTS audio
  html.AudioElement? _audioElement;

  /// Handle message received from server
  void _handleMessageReceived(String message, {String? audioBase64}) {
    debugPrint('[RtcService] 收到消息: $message');
    
    // 触发消息接收回调
    _messageController.add(message);
  }

  /// Audio state change callback
  Function(bool hasAudio)? _audioStateChangeCallback;

  /// Create a new RTC service
  RtcService({
    required this.config,
  }) {
    // 创建音频元素
    _audioElement = html.AudioElement();
    _audioElement?.autoplay = false;
  }

  @override
  Future<void> initialize() async {
    try {
      // 确保SDK已加载
      await WebUtils.waitForSdkLoaded();

      // 检查SDK是否可用
      if (!WebUtils.isSdkLoaded()) {
        throw Exception('VERTC SDK not loaded properly');
      }

      // 验证 userId 格式
      final validatedUserId = _validateUserId(config.userId);
      if (validatedUserId != config.userId) {
        debugPrint(
            'UserId format adjusted to meet SDK requirements: $validatedUserId');
      }

      // 初始化HTTP客户端
      if (config.serverUrl != null && config.serverUrl!.isNotEmpty) {
        _aigcClient = AigcClient(
          baseUrl: config.serverUrl!,
          appId: config.appId,
          roomId: config.roomId,
          userId: config.userId,
        );
        
        _aigcClient!.registerResponseCallback(_handleMessageReceived);
        debugPrint('AIGC HTTP client initialized with serverUrl: ${config.serverUrl}');
      }

      // 创建RTC客户端实例 - 用于麦克风和摄像头控制
      _rtcClient = js.JsObject(js.context['RtcClient'], [
        js.JsObject.jsify({
          'appId': config.appId,
          'roomId': config.roomId,
          'userId': validatedUserId,
          'token': config.token,
        })
      ]);

      // 设置设备监听器
      _setupDeviceListeners();

      debugPrint('RTC service initialized successfully');
    } catch (e) {
      debugPrint('Failed to initialize RTC service: $e');
      rethrow;
    }
  }

  /// Set up device change listeners
  void _setupDeviceListeners() {
    // 只在设备状态控制器未关闭时进行设备检查
    if (!_deviceStateController.isClosed) {
      // 初始设备检查
      _checkDeviceAvailability();
    }
  }

  /// Check if audio/video devices are available
  Future<void> _checkDeviceAvailability() async {
    try {
      final devices =
          await html.window.navigator.mediaDevices?.enumerateDevices();
      final hasAudioInput =
          devices?.any((device) => device.kind == 'audioinput') ?? false;
      final hasVideoInput =
          devices?.any((device) => device.kind == 'videoinput') ?? false;

      if (!_deviceStateController.isClosed) {
        _deviceStateController.add(hasAudioInput && hasVideoInput);
      }
    } catch (e) {
      debugPrint('Error checking device availability: $e');
      if (!_deviceStateController.isClosed) {
        _deviceStateController.add(false);
      }
    }
  }
  
  /// 验证并格式化 userId 以符合 SDK 要求
  /// 要求：长度不超过 128 字节，只能包含 a-z, A-Z, 0-9, @, -, _, .
  String _validateUserId(String? userId) {
    if (userId == null || userId.isEmpty) {
      // 生成一个随机有效的 ID
      final randomId = 'user_${DateTime.now().millisecondsSinceEpoch}';
      debugPrint('No userId provided, using random ID: $randomId');
      return randomId;
    }

    // 检查是否包含无效字符
    final validRegex = RegExp(r'^[a-zA-Z0-9@\-_.]+$');
    if (!validRegex.hasMatch(userId)) {
      // 清理无效字符
      final cleanId = userId.replaceAll(RegExp(r'[^a-zA-Z0-9@\-_.]'), '_');
      debugPrint('Invalid characters in userId, cleaned to: $cleanId');
      return cleanId;
    }

    // 检查长度
    if (userId.length > 128) {
      final truncatedId = userId.substring(0, 128);
      debugPrint('userId too long, truncated to: $truncatedId');
      return truncatedId;
    }

    return userId;
  }

  /// 处理接收到的音频数据
  void _handleAudioReceived(Uint8List audioData) {
    debugPrint('Received audio data from AI: ${audioData.length} bytes');
    _playAudio(audioData);
  }

  /// 播放音频数据
  void _playAudio(Uint8List audioData) {
    try {
      if (_audioElement == null) return;

      // 转换为base64字符串
      final base64Audio = base64Encode(audioData);
      final audioSrc = 'data:audio/mp3;base64,$base64Audio';
      
      // 设置音频源
      _audioElement!.src = audioSrc;
      
      // 播放音频
      _audioElement!.play();
      
      // 设置音频播放和结束事件
      _audioElement!.onPlay.listen((_) {
        debugPrint('Audio playback started');
        if (!_connectionStateController.isClosed) {
          _connectionStateController.add('audio_playing');
        }
      });
      
      _audioElement!.onEnded.listen((_) {
        debugPrint('Audio playback completed');
        if (!_connectionStateController.isClosed) {
          _connectionStateController.add('audio_stopped');
        }
      });
    } catch (e) {
      debugPrint('Error playing audio: $e');
    }
  }

  /// Initialize AIGC client
  Future<bool> _initializeAigcClient() async {
    if (_aigcClient == null) {
      _aigcClient = AigcClient(
        baseUrl: config.serverUrl ?? 'https://open.volcengineapi.com',
        appId: config.appId,
        roomId: config.roomId,
        userId: config.userId,
      );
      
      _aigcClient!.registerResponseCallback(_handleMessageReceived);
      return true;
    }
    return false;
  }
  
  /// Start a conversation
  Future<bool> startConversation({
    String? welcomeMessage,
    String? businessId,
    Map<String, dynamic>? asrConfig,
    Map<String, dynamic>? ttsConfig,
    Map<String, dynamic>? llmConfig,
  }) async {
    if (_isConversationActive) {
      debugPrint('Conversation is already active');
      return true;
    }

    try {
      await _initializeAigcClient();
      
      if (_aigcClient == null) {
        throw Exception('AIGC client initialization failed');
      }

      // Generate task ID
      final taskId = config.taskId ?? _generateTaskId();
      _currentTaskId = taskId;

      // Create request parameters
      final params = {
        'Command': 'START',
        'AppId': config.appId,
        'RoomId': config.roomId,
        'UserId': config.userId,
        'Token': config.token,
        'TaskId': taskId,
        'Config': <String, dynamic>{},
        'AgentConfig': {
          'TargetUserId': [config.userId],
          'WelcomeMessage': welcomeMessage,
          'UserID': 'BotName001'
        }
      };

      if (asrConfig != null) {
        (params['Config'] as Map<String, dynamic>)['AsrConfig'] = asrConfig;
      }

      if (ttsConfig != null) {
        (params['Config'] as Map<String, dynamic>)['TtsConfig'] = ttsConfig;
      }

      if (llmConfig != null) {
        (params['Config'] as Map<String, dynamic>)['LlmConfig'] = llmConfig;
      }

      final response = await _aigcClient!.startVoiceChat(params);
      
      _isConversationActive = true;
      debugPrint('Conversation started with task ID: $_currentTaskId');
      return true;
    } catch (e) {
      debugPrint('Error starting conversation: $e');
      _isConversationActive = false;
      return false;
    }
  }
  
  /// Send a message
  Future<bool> sendMessage(String message) async {
    if (!_isConversationActive || _aigcClient == null || _currentTaskId == null) {
      debugPrint('Cannot send message: no active conversation');
      return false;
    }

    try {
      await _aigcClient!.sendMessage(
        taskId: _currentTaskId!,
        message: message,
      );
      return true;
    } catch (e) {
      debugPrint('Error sending message: $e');
      return false;
    }
  }

  /// Stop the conversation
  Future<bool> stopConversation() async {
    if (!_isConversationActive || _aigcClient == null || _currentTaskId == null) {
      debugPrint('No active conversation to stop');
      return true;
    }

    try {
      // Create request parameters
      final params = {
        'Command': 'STOP',
        'AppId': config.appId,
        'RoomId': config.roomId,
        'UserId': config.userId,
        'TaskId': _currentTaskId!,
      };

      await _aigcClient!.stopVoiceChat(params);
      _isConversationActive = false;
      _currentTaskId = null;
      debugPrint('Conversation stopped');
      return true;
    } catch (e) {
      debugPrint('Error stopping conversation: $e');
      return false;
    }
  }

  /// Request microphone access
  Future<bool> requestMicrophoneAccess() async {
    if (_isMicrophoneActive) return true;
    if (_rtcClient == null) return false;

    try {
      final constraints = {
        'audio': true,
      };

      final stream = await html.window.navigator.mediaDevices?.getUserMedia(constraints);
      
      if (stream != null) {
        // 使用WebUtils确保安全调用JS方法
        WebUtils.safeJsCall(_rtcClient, 'setLocalAudioStream', [stream]);
        _isMicrophoneActive = true;
        // 只是检查权限，停止流
        stream.getTracks().forEach((track) => track.stop());
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error requesting microphone access: $e');
      return false;
    }
  }

  /// Request camera access
  Future<bool> requestCameraAccess() async {
    if (_isCameraActive) return true;
    if (_rtcClient == null) return false;

    try {
      final constraints = {
        'video': true,
      };

      final stream = await html.window.navigator.mediaDevices?.getUserMedia(constraints);
      
      if (stream != null) {
        // 使用WebUtils确保安全调用JS方法
        WebUtils.safeJsCall(_rtcClient, 'setLocalVideoStream', [stream]);
        _isCameraActive = true;
        // 只是检查权限，停止流
        stream.getTracks().forEach((track) => track.stop());
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error requesting camera access: $e');
      return false;
    }
  }

  /// Stop local audio stream
  Future<void> stopLocalAudio() async {
    if (!_isMicrophoneActive || _rtcClient == null) return;

    try {
      WebUtils.safeJsCall(_rtcClient, 'stopLocalAudio');
      _isMicrophoneActive = false;
    } catch (e) {
      debugPrint('Error stopping local audio: $e');
    }
  }

  /// Stop local video stream
  Future<void> stopLocalVideo() async {
    if (!_isCameraActive || _rtcClient == null) return;

    try {
      WebUtils.safeJsCall(_rtcClient, 'stopLocalVideo');
      _isCameraActive = false;
    } catch (e) {
      debugPrint('Error stopping local video: $e');
    }
  }

  /// Generate a unique task ID
  String _generateTaskId() {
    final now = DateTime.now().millisecondsSinceEpoch;
    return 'rtc_task_${now}';
  }

  /// Join RTC channel
  Future<bool> joinChannel() async {
    try {
      if (_isConversationActive) {
        debugPrint('[RtcService] 已经加入频道，不再重复加入');
        return true;
      }
    
      debugPrint('[RtcService] 正在加入RTC频道...');
      // RTC相关逻辑，成功则设置状态
      _isConversationActive = true;
      return true;
    } catch (e) {
      debugPrint('[RtcService] 加入频道失败: $e');
      return false;
    }
  }
  
  /// Leave RTC channel
  Future<bool> leaveChannel() async {
    try {
      if (!_isConversationActive) {
        debugPrint('[RtcService] 未加入频道，无需离开');
        return true;
      }
    
      debugPrint('[RtcService] 正在离开RTC频道...');
      // RTC相关逻辑，成功则设置状态
      _isConversationActive = false;
      return true;
    } catch (e) {
      debugPrint('[RtcService] 离开频道失败: $e');
      return false;
    }
  }
  
  /// Set audio state change callback
  void setAudioStateChangeCallback(Function(bool hasAudio) callback) {
    _audioStateChangeCallback = callback;
  }

  @override
  Future<void> dispose() async {
    // 停止会话
    await stopConversation();

    // 确保资源正确释放
    try {
      if (!_deviceStateController.isClosed) {
        await _deviceStateController.close();
      }
      if (!_messageController.isClosed) {
        await _messageController.close();
      }
      if (!_connectionStateController.isClosed) {
        await _connectionStateController.close();
      }
      
      // 释放HTTP客户端
      _aigcClient?.dispose();
      _aigcClient = null;
    } catch (e) {
      debugPrint('Error closing controllers: $e');
    }

    // 清理音频元素
    _audioElement?.pause();
    _audioElement?.remove();
    _audioElement = null;
  }
}
