import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:rtc_aigc_plugin/src/client/aigc_client.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'service_interface.dart';

/// Callback for AI response text updates
typedef AiResponseCallback = void Function(String text);

/// Callback type for LLM message events
typedef LlmMessageCallback = void Function(String message, bool isUser);

/// LLM (Large Language Model) service
class LlmService implements Service {
  /// Configuration for the LLM service
  final LlmConfig _config;
  
  /// AIGC client for API requests
  AigcClient? _client;
  
  /// Callback for message events
  LlmMessageCallback? _onMessage;
  
  /// Current session ID
  String? _sessionId;
  
  /// Session history
  final List<Map<String, dynamic>> _sessionHistory = [];
  
  /// Is conversation active
  bool _isConversationActive = false;
  
  /// Is service initialized
  bool _isInitialized = false;

  /// LLM service constructor
  LlmService(this._config, {AigcClient? client}) : _client = client;

  /// Client setter
  set client(AigcClient? value) {
    _client = value;
  }

  @override
  Future<void> initialize() async {
    try {
      if (_client == null) {
        debugPrint('LLM初始化失败: AIGC客户端未提供');
        throw Exception('AIGC client is required');
      }

      if (_config.appId.isEmpty || 
          (_config.modelName?.isEmpty ?? true)) {
        debugPrint('LLM初始化失败: 配置不完整');
        throw Exception('Incomplete LLM configuration');
      }

      _isInitialized = true;
      debugPrint('LLM服务初始化成功');
    } catch (e) {
      debugPrint('LLM初始化失败: $e');
      rethrow;
    }
  }
  
  /// Register message callback
  void registerMessageCallback(LlmMessageCallback callback) {
    _onMessage = callback;
  }
  
  /// Is service initialized
  bool get isInitialized => _isInitialized;
  
  /// Is conversation active
  bool get isConversationActive => _isConversationActive;

  /// Start a conversation
  Future<bool> startConversation(String? welcomeMessage) async {
    if (!_isInitialized || _client == null) {
      debugPrint('LLM服务未初始化，无法开始对话');
      return false;
    }

    try {
      // 清除现有会话历史
      _sessionHistory.clear();
      
      // 添加系统消息作为历史记录的开始
      if (_config.systemMessages != null && _config.systemMessages!.isNotEmpty) {
        for (final message in _config.systemMessages!) {
          _sessionHistory.add({
            'role': 'system',
            'content': message,
          });
        }
      }
      
      // 开始语音聊天 - 使用START命令
      final response = await _client!.startVoiceChat({
        'Command': 'START',
        'AppId': _config.appId,
        'UserId': _client!.userId,
        'ModelInfo': {
          'ModelName': _config.modelName ?? '',
        },
        'ParamsInfo': {
          'WelcomeSpeech': welcomeMessage ?? _config.welcomeSpeech,
          'InitMessages': _config.systemMessages,
        }
      });

      if (response.containsKey('TaskId')) {
        _sessionId = response['TaskId'];
        _isConversationActive = true;
        debugPrint('LLM会话已开始，TaskId: $_sessionId');
        
        // 如果有欢迎语，触发消息回调
        final welcomeSpeech = welcomeMessage ?? _config.welcomeSpeech;
        if (welcomeSpeech != null && welcomeSpeech.isNotEmpty && _onMessage != null) {
          _onMessage!(welcomeSpeech, false);
        }
        
        // 注册接收AI消息的回调
        _client!.registerResponseCallback(_handleAiResponse);
        
        return true;
      } else {
        debugPrint('LLM会话启动失败: 未返回TaskId, 响应: ${jsonEncode(response)}');
        return false;
      }
    } catch (e, stackTrace) {
      debugPrint('启动LLM会话时出错: $e');
      debugPrint('堆栈跟踪: $stackTrace');
      return false;
    }
  }

  /// Handle AI responses
  void _handleAiResponse(String text, {String? audioBase64}) {
    if (_onMessage != null) {
      _onMessage!(text, false);
    }
    
    // 将AI响应添加到会话历史
    _sessionHistory.add({
      'role': 'assistant',
      'content': text,
    });
  }

  /// Send a message to the LLM
  Future<bool> sendMessage(String message) async {
    if (!_isInitialized || _client == null || _sessionId == null) {
      debugPrint('LLM服务未初始化或会话未开始，无法发送消息');
      return false;
    }

    try {
      // 添加用户消息到会话历史
      _sessionHistory.add({
        'role': 'user',
        'content': message,
      });
      
      // 如果配置了回调，调用它
      if (_onMessage != null) {
        _onMessage!(message, true);
      }

      // 准备消息请求
      final messageRequest = {
        'Command': 'UPDATE', // 添加Command字段
        'TaskId': _sessionId,
        'ParamsInfo': {
          'Messages': [
            {
              'Role': 'user',
              'Content': message,
            }
          ],
          'MessageHistory': _sessionHistory.map((msg) => {
            'Role': msg['role'],
            'Content': msg['content'],
          }).toList(),
        }
      };
      
      debugPrint('发送LLM消息: ${jsonEncode(messageRequest)}');
      
      // 发送更新请求
      final response = await _client!.updateVoiceChat(messageRequest);
      
      // 检查响应
      if (response.containsKey('RetCode') && response['RetCode'] == 0) {
        debugPrint('LLM消息发送成功');
        return true;
      } else {
        debugPrint('LLM消息发送失败: ${jsonEncode(response)}');
        return false;
      }
    } catch (e, stackTrace) {
      debugPrint('发送LLM消息时出错: $e');
      debugPrint('堆栈跟踪: $stackTrace');
      return false;
    }
  }

  /// Stop the current conversation
  Future<bool> stopConversation() async {
    if (!_isInitialized || _client == null || _sessionId == null) {
      debugPrint('LLM服务未初始化或会话未开始，无法停止对话');
      return false;
    }

    try {
      // 发送STOP命令
      final response = await _client!.stopVoiceChat({
        'Command': 'STOP',
        'TaskId': _sessionId,
      });
      
      // 取消注册消息回调
      _client!.unregisterResponseCallback();
      
      // 清除会话ID和历史
      _sessionId = null;
      _sessionHistory.clear();
      _isConversationActive = false;
      
      if (response.containsKey('RetCode') && response['RetCode'] == 0) {
        debugPrint('LLM会话已停止');
        return true;
      } else {
        debugPrint('LLM会话停止失败: ${jsonEncode(response)}');
        return false;
      }
    } catch (e, stackTrace) {
      debugPrint('停止LLM会话时出错: $e');
      debugPrint('堆栈跟踪: $stackTrace');
      return false;
    }
  }

  /// Dispose of resources
  @override
  Future<void> dispose() async {
    _isInitialized = false;
    _isConversationActive = false;
    _sessionId = null;
    _sessionHistory.clear();
    _onMessage = null;
  }
}

