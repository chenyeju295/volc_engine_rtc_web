import 'dart:async';
import 'dart:convert';
import 'dart:js' as js;
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_message_handler.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_event_manager.dart';
import 'package:rtc_aigc_plugin/src/utils/web_utils.dart';

/// Manages AI conversations and interactions
class RtcConversationManager {
  final RtcConfig config;
  final RtcMessageHandler messageHandler;
  final RtcEventManager eventManager;
  
  dynamic _rtcClient;
  dynamic _aigcClient;
  
  // Conversation state
  bool _isConversationActive = false;
  bool _isAIThinking = false;
  bool _isAITalking = false;
  String? _currentTaskId;
  
  // Getters for current state
  bool get isConversationActive => _isConversationActive;
  bool get isAIThinking => _isAIThinking;
  bool get isAITalking => _isAITalking;
  String? get currentTaskId => _currentTaskId;
  
  RtcConversationManager({
    required this.config,
    required this.messageHandler,
    required this.eventManager,
  });
  
  void setEngine(dynamic rtcClient, dynamic aigcClient) {
    _rtcClient = rtcClient;
    _aigcClient = aigcClient;
  }
  
  /// 生成任务ID
  String _generateTaskId() {
    // 生成一个包含随机数的唯一ID，格式与Web demo一致
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final random = Random().nextInt(10000).toString().padLeft(4, '0');
    final userId = config.userId.toLowerCase();

    // 格式: userId_timestamp_random
    return '${userId}_${timestamp}_$random';
  }
  
  /// 开始对话
  Future<Map<String, dynamic>> startConversation({String? welcomeMessage}) async {
    debugPrint('【会话】开始AIGC对话，欢迎语: $welcomeMessage');

    if (_rtcClient == null || _aigcClient == null) {
      debugPrint('【会话】错误: 尝试在引擎未初始化时开始对话');
      return {'success': false, 'taskId': null};
    }

    if (_isConversationActive) {
      debugPrint('【会话】警告: 对话已经处于活跃状态，先停止当前对话');
      await stopConversation();
    }

    // 生成任务ID
    final taskId = _generateTaskId();
    debugPrint('【会话】使用的任务ID: $taskId');
    _currentTaskId = taskId;

    try {
      // 启动AIGC服务
      final aigcResult = await _startAIGCService(
        taskId: taskId,
        welcomeMessage: welcomeMessage ?? config.llmConfig?.welcomeSpeech,
      );

      if (!aigcResult) {
        debugPrint('【会话】启动AIGC服务失败');
        _currentTaskId = null;
        return {'success': false, 'taskId': null};
      }

      // 发送任务开始消息
      final taskStartInfo = {
        'type': 'task_started',
        'taskId': taskId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
      
      // 添加到消息历史
      messageHandler.addMessageToHistory(taskStartInfo);
      
      // 更新状态
      _isConversationActive = true;
      
      // 通知事件管理器对话已开始
      eventManager.reportConversationState(active: true, taskId: taskId);
      
      debugPrint('【会话】AIGC对话已成功启动，任务ID: $taskId');
      return {'success': true, 'taskId': taskId};
    } catch (e) {
      debugPrint('【会话】开始AIGC对话时发生错误: $e');
      _currentTaskId = null;
      return {'success': false, 'taskId': null};
    }
  }
  
  /// 停止对话
  Future<bool> stopConversation() async {
    if (!_isConversationActive) {
      debugPrint('【会话】没有正在进行的对话，无需停止');
      return true;
    }

    try {
      debugPrint('【会话】正在停止AI对话...');

      // 如果AI正在思考或说话，先中断它
      if (_isAIThinking || _isAITalking) {
        await interruptConversation();
      }

      // 如果当前有taskId，则停止AIGC服务
      if (_currentTaskId != null && _aigcClient != null) {
        try {
          debugPrint('【会话】通过AIGC客户端停止会话，任务ID: $_currentTaskId');

          final stopResult = await _aigcClient.stopVoiceChat(
            roomId: config.roomId.toLowerCase(),
            userId: _validateUserId(config.userId).toLowerCase(),
            taskId: _currentTaskId!,
          );

          debugPrint('【会话】AIGC服务停止结果: ${stopResult["Result"] ?? "unknown"}');
        } catch (e) {
          debugPrint('【会话】AIGC客户端停止会话失败: $e');
          // 继续执行其他清理步骤
        }
      } else {
        debugPrint('【会话】通过RTC客户端停止对话');
        WebUtils.safeJsCall(_rtcClient, 'stopAudioBot', []);
      }

      // 发送任务结束消息到UI
      final taskStopInfo = {
        'type': 'task_stopped',
        'taskId': _currentTaskId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      // 添加到消息历史
      messageHandler.addMessageToHistory(taskStopInfo);

      // 重置状态
      _isConversationActive = false;
      _isAIThinking = false;
      _isAITalking = false;
      
      // 通知事件管理器对话已停止
      eventManager.reportConversationState(active: false, taskId: _currentTaskId);
      
      _currentTaskId = null;

      // 清空消息缓存
      messageHandler.clearMessageCache();

      debugPrint('【会话】AI对话已成功停止');
      return true;
    } catch (e) {
      debugPrint('【会话】停止AI对话时出错: $e');
      return false;
    }
  }
  
  /// 中断AI的对话
  Future<bool> interruptConversation() async {
    if (!_isConversationActive) {
      debugPrint('【对话控制】对话尚未开始，无法打断');
      return false;
    }

    if (!_isAIThinking && !_isAITalking) {
      debugPrint('【对话控制】AI当前未在说话或思考，无需打断');
      return true;
    }

    try {
      debugPrint('【对话控制】正在发送打断命令...');

      // 使用标准化的中断命令结构
      final interruptData = {
        'Command': 'INTERRUPT',
        'InterruptMode': 0,
        'Message': ''
      };

      // 发送中断命令到AIGC服务
      if (_aigcClient != null && _currentTaskId != null) {
        final result = await _aigcClient.updateVoiceChat(
          roomId: config.roomId.toLowerCase(),
          userId: _validateUserId(config.userId).toLowerCase(),
          taskId: _currentTaskId!,
        );

        debugPrint('【对话控制】打断命令已发送，结果: ${result["Result"]}');
      } else {
        // 如果AIGC客户端未初始化，则使用RTC客户端发送中断命令
        final jsResult = WebUtils.safeJsCall(
            _rtcClient, 'sendInterruptCommand', ['INTERRUPT']);
        debugPrint('【对话控制】通过RTC客户端发送打断命令，结果: $jsResult');
      }

      // 立即更新UI状态
      eventManager.handleAIStateChange('INTERRUPTED', '用户已打断会话');
      
      // 更新本地状态
      _isAIThinking = false;
      _isAITalking = false;

      return true;
    } catch (e) {
      debugPrint('【对话控制】发送打断命令失败: $e');
      return false;
    }
  }
  
  /// 发送消息
  Future<bool> sendMessage(String message) async {
    if (!_isConversationActive) {
      debugPrint('【会话】会话尚未开始，无法发送消息');
      return false;
    }

    if (_currentTaskId == null || _aigcClient == null) {
      debugPrint('【会话】AIGC客户端或任务ID未初始化，无法发送消息');
      return false;
    }

    try {
      debugPrint('【会话】正在通过AIGC客户端发送消息: $message');

      // 在发送前，添加用户消息到历史
      final userMessageMap = {
        'text': message,
        'isFinal': true,
        'userId': 'user',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
      
      // 添加到消息历史
      messageHandler.addMessageToHistory(userMessageMap);
      
      // 使用AIGC客户端发送消息
      await _aigcClient.sendMessage(
        roomId: config.roomId.toLowerCase(),
        userId: _validateUserId(config.userId).toLowerCase(),
        taskId: _currentTaskId!,
        message: message,
      );

      debugPrint('【会话】消息已成功发送: $message');
      return true;
    } catch (e) {
      debugPrint('【会话】发送消息失败: $e');
      return false;
    }
  }
  
  /// 测试AI字幕功能（仅用于开发测试）
  Future<bool> testAISubtitle(String text, {bool isFinal = false}) async {
    try {
      if (!_isConversationActive) {
        debugPrint('【测试】测试AI字幕失败：会话尚未开始');
        return false;
      }

      // 手动构造字幕事件以支持测试
      final subtitleMap = <String, dynamic>{
        'text': text,
        'isFinal': isFinal,
        'userId': 'BotName001',
        'paragraph': false,
        'language': 'zh',
        'sequence': 0,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      // 添加到消息历史
      messageHandler.addMessageToHistory(subtitleMap);

      debugPrint('【测试】测试AI字幕成功：$text');
      return true;
    } catch (e) {
      debugPrint('【测试】测试AI字幕出错: $e');
      return false;
    }
  }
  
  /// 启动AIGC服务
  Future<bool> _startAIGCService({
    required String taskId, 
    String? welcomeMessage
  }) async {
    debugPrint('【AIGC】启动AIGC服务, 任务ID: $taskId');

    if (_aigcClient == null) {
      debugPrint('【AIGC】错误: AIGC客户端未初始化');
      return false;
    }

    try {
      // 确保使用与Web Demo一致的参数结构
      final result = await _aigcClient.startVoiceChat(
        roomId: config.roomId,
        userId: config.userId,
        token: config.token,
        taskId: taskId,
        businessId: config.businessId,
        welcomeMessage: welcomeMessage ?? '你好，我是你的AI小助手，有什么可以帮你的吗？',
        asrConfig: config.asrConfig,
        ttsConfig: config.ttsConfig,
        llmConfig: config.llmConfig,
      );

      debugPrint('【AIGC】AIGC服务启动结果: $result');
      return result['Result'] == 'ok';
    } catch (e) {
      debugPrint('【AIGC】启动AIGC服务时发生错误: $e');
      return false;
    }
  }
  
  /// 验证并格式化 userId 以符合 SDK 要求
  String _validateUserId(String? userId) {
    if (userId == null || userId.isEmpty) {
      final randomId = 'user_${DateTime.now().millisecondsSinceEpoch}';
      debugPrint('【会话】没有提供userId，使用随机ID: $randomId');
      return randomId;
    }

    // 检查是否包含无效字符
    final validRegex = RegExp(r'^[a-zA-Z0-9@\-_.]+$');
    if (!validRegex.hasMatch(userId)) {
      // 清理无效字符
      final cleanId = userId.replaceAll(RegExp(r'[^a-zA-Z0-9@\-_.]'), '_');
      debugPrint('【会话】userId包含无效字符，已清理为: $cleanId');
      return cleanId;
    }

    // 检查长度
    if (userId.length > 128) {
      final truncatedId = userId.substring(0, 128);
      debugPrint('【会话】userId过长，已截断为: $truncatedId');
      return truncatedId;
    }

    return userId;
  }
  
  Future<void> dispose() async {
    try {
      if (_isConversationActive) {
        await stopConversation();
      }
      
      _isConversationActive = false;
      _isAIThinking = false;
      _isAITalking = false;
      _currentTaskId = null;
      
      debugPrint('RTC会话管理器已清理');
    } catch (e) {
      debugPrint('清理RTC会话管理器时出错: $e');
    }
  }
} 