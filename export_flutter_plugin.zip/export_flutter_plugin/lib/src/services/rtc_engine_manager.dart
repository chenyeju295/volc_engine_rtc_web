import 'dart:async';
import 'dart:js' as js;
import 'package:flutter/foundation.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'package:rtc_aigc_plugin/src/utils/web_utils.dart';
import 'package:rtc_aigc_plugin/src/client/aigc_client.dart';

/// Manages the RTC and AIGC engine initialization and core functionality
class RtcEngineManager {
  final RtcConfig config;
  dynamic rtcClient;
  dynamic aigcClient;
  bool isInitialized = false;
  bool isInRoom = false;
  
  RtcEngineManager({required this.config});
  
  Future<bool> initialize() async {
    try {
      debugPrint('【RTC引擎】开始初始化RTC引擎...');
      
      // Create AIGC client
      aigcClient = AigcClient(
        appId: config.appId,
        baseUrl: config.serverUrl ?? '',
        asrConfig: config.asrConfig,
        ttsConfig: config.ttsConfig,
        llmConfig: config.llmConfig,
      );
      
      debugPrint('【RTC引擎】AIGC客户端创建完成, 服务URL: ${config.serverUrl}');
      
      // Initialize RTC engine
      await _initializeRtcEngine();
      isInitialized = true;
      
      debugPrint('【RTC引擎】初始化完成');
      return true;
    } catch (e) {
      debugPrint('【RTC引擎】初始化失败: $e');
      return false;
    }
  }
  
  Future<void> _initializeRtcEngine() async {
    // Wait for SDK to load
    debugPrint('【RTC引擎】正在加载RTC SDK...');
    await WebUtils.waitForSdkLoaded();
    
    // Verify SDK availability 
    if (!WebUtils.isSdkLoaded()) {
      debugPrint('【RTC引擎】VERTC SDK加载失败');
      throw Exception('VERTC SDK not loaded properly');
    }
    debugPrint('【RTC引擎】VERTC SDK加载成功');
    
    // Validate userId format
    final validatedUserId = _validateUserId(config.userId);
    debugPrint('【RTC引擎】验证后的userId: $validatedUserId');
    
    // Create RTC client instance
    final jsOptions = {
      'appId': config.appId,
      'roomId': config.roomId.toLowerCase(),
      'userId': validatedUserId.toLowerCase(),
      'token': config.token,
    };
    
    debugPrint('【RTC引擎】创建RTC客户端, 参数: $jsOptions');
    rtcClient = js.JsObject(js.context['RtcClient'], [js.JsObject.jsify(jsOptions)]);
    
    debugPrint('【RTC引擎】RTC引擎初始化成功');
  }
  
  /// 验证并格式化 userId 以符合 SDK 要求
  /// 要求：长度不超过 128 字节，只能包含 a-z, A-Z, 0-9, @, -, _, .
  String _validateUserId(String? userId) {
    if (userId == null || userId.isEmpty) {
      // 生成一个随机有效的 ID
      final randomId = 'user_${DateTime.now().millisecondsSinceEpoch}';
      debugPrint('No userId provided, using random ID: $randomId');
      return randomId;
    }

    // 检查是否包含无效字符
    final validRegex = RegExp(r'^[a-zA-Z0-9@\-_.]+$');
    if (!validRegex.hasMatch(userId)) {
      // 清理无效字符
      final cleanId = userId.replaceAll(RegExp(r'[^a-zA-Z0-9@\-_.]'), '_');
      debugPrint('Invalid characters in userId, cleaned to: $cleanId');
      return cleanId;
    }

    // 检查长度
    if (userId.length > 128) {
      final truncatedId = userId.substring(0, 128);
      debugPrint('userId too long, truncated to: $truncatedId');
      return truncatedId;
    }

    return userId;
  }
  
  void registerEventHandlers({
    Function(dynamic, dynamic)? onBinaryMessage,
    Function(dynamic)? onSubtitle,
    Function(dynamic)? onUserJoined,
    Function(dynamic)? onUserLeave,
    Function(dynamic)? onUserStartAudioCapture,
    Function(dynamic)? onUserStopAudioCapture,
    Function(dynamic)? onAutoPlayFail,
  }) {
    try {
      debugPrint('【事件系统】正在注册RTC事件处理程序...');

      // 创建回调对象
      final callbacks = js.JsObject.jsify({
        'onUserJoined': js.allowInterop(onUserJoined ?? (dynamic userData) {
          debugPrint(
              '【事件系统】用户加入: ${userData is Map ? userData['userId'] : userData}');
        }),
        
        'onUserLeave': js.allowInterop(onUserLeave ?? (dynamic userData) {
          debugPrint(
              '【事件系统】用户离开: ${userData is Map ? userData['userId'] : userData}');
        }),
        
        'onRoomBinaryMessageReceived': js.allowInterop(onBinaryMessage ?? (dynamic messageData) {
          final userId = messageData is Map ? messageData['userId'] : messageData;
          final message = messageData is Map ? messageData['message'] : null;
          debugPrint('【事件系统】收到二进制消息: $userId');
        }),
        
        'onSubtitle': js.allowInterop(onSubtitle ?? (dynamic subtitleData) {
          if (subtitleData == null) {
            debugPrint('【事件系统】收到空的字幕数据');
            return;
          }
          debugPrint('【事件系统】收到字幕数据');
        }),
        
        'onUserStartAudioCapture': js.allowInterop(onUserStartAudioCapture ?? (dynamic userData) {
          final userId = userData is Map ? userData['userId'] : userData;
          debugPrint('【事件系统】用户开始音频采集: $userId');
        }),
        
        'onUserStopAudioCapture': js.allowInterop(onUserStopAudioCapture ?? (dynamic userData) {
          final userId = userData is Map ? userData['userId'] : userData;
          debugPrint('【事件系统】用户停止音频采集: $userId');
        }),
        
        'onAutoPlayFail': js.allowInterop(onAutoPlayFail ?? (dynamic errorData) {
          debugPrint('【事件系统】自动播放失败: $errorData');
        }),
      });

      // 使用JS调用注册回调
      WebUtils.safeJsCall(rtcClient, 'registerEventCallbacks', [callbacks]);
      debugPrint('【事件系统】RTC事件处理程序注册完成');
    } catch (e) {
      debugPrint('【事件系统】注册RTC事件处理程序失败: $e');
    }
  }
  
  Future<bool> joinRoom({String? serverUrl}) async {
    if (rtcClient == null) {
      debugPrint('【加入房间】RTC客户端未初始化，无法加入房间');
      return false;
    }

    try {
      debugPrint('【加入房间】正在加入RTC房间: ${config.roomId.toLowerCase()}');
      debugPrint('【加入房间】token: ${config.token != null ? '已设置' : '未设置'}');

      // 设置用户信息
      final userInfoMap = {
        'userId': _validateUserId(config.userId).toLowerCase(),
        'extraInfo': js.JsObject.jsify({
          'user_name': 'Flutter User',
          'user_id': config.userId,
          'call_scene': 'RTC-AIGC',
        }),
      };

      debugPrint('【加入房间】用户信息: $userInfoMap');
      final userInfo = js.JsObject.jsify(userInfoMap);

      // 设置加入房间选项
      final roomOptionsMap = {
        'isAutoPublish': true,
        'isAutoSubscribeAudio': true,
        'roomProfileType': 5
      };

      debugPrint('【加入房间】房间选项: $roomOptionsMap');
      final roomOptions = js.JsObject.jsify(roomOptionsMap);

      // 将参数传递给joinRoomAndSetupAudio方法
      debugPrint('【加入房间】调用joinRoomAndSetupAudio方法...');
      final jsConfig = js.JsObject.jsify({
        'userName': 'Flutter User',
        'serverUrl': serverUrl ?? config.serverUrl,
      });

      final result = WebUtils.safeJsCall(rtcClient, 'joinRoomAndSetupAudio', [jsConfig]);

      // 检查结果
      if (result == null || result == false) {
        debugPrint('【加入房间】加入房间失败，JavaScript返回: $result');
        isInRoom = false;
        return false;
      }

      // 等待短暂时间以确保事件有时间被触发
      await Future.delayed(const Duration(milliseconds: 500));

      isInRoom = true;
      debugPrint('【加入房间】成功加入房间');
      
      // 启用音频属性报告
      _enableAudioPropertiesReport();
      
      return true;
    } catch (e) {
      debugPrint('【加入房间】加入房间失败: $e');
      isInRoom = false;
      return false;
    }
  }
  
  /// 启用音频属性报告
  void _enableAudioPropertiesReport() {
    try {
      if (rtcClient == null) {
        debugPrint('【音频属性】RTC客户端未初始化，无法启用音频属性报告');
        return;
      }

      debugPrint('【音频属性】尝试启用音频属性报告...');
      final rtcEngine = rtcClient['rtcEngine'];

      if (rtcEngine != null) {
        // 调用enableAudioPropertiesReport方法
        final options = {'interval': 1000};
        debugPrint('【音频属性】启用参数: $options');

        WebUtils.safeJsCall(rtcEngine, 'enableAudioPropertiesReport', [js.JsObject.jsify(options)]);
        debugPrint('【音频属性】音频属性报告已启用');
      } else {
        debugPrint('【音频属性】无法获取RTC引擎对象，将跳过音频属性报告');
      }
    } catch (e) {
      debugPrint('【音频属性】启用音频属性报告失败 (非致命): $e');
    }
  }
  
  Future<bool> leaveRoom({bool leaveOnly = false, String? serverUrl}) async {
    if (rtcClient == null) {
      debugPrint('RTC客户端未初始化，无法离开房间');
      return false;
    }

    try {
      debugPrint('正在离开RTC房间');

      // 传递serverUrl参数以便正确调用StopVoiceChat API
      await WebUtils.safeJsCall(
          rtcClient, 'cleanupAndLeaveRoom', [config.serverUrl, config.appId]);

      isInRoom = false;
      debugPrint('已成功离开RTC房间');
      return true;
    } catch (e) {
      debugPrint('离开RTC房间时出错: $e');
      isInRoom = false;
      return false;
    }
  }
  
  Future<void> dispose() async {
    try {
      if (isInRoom) {
        await leaveRoom();
      }
      
      rtcClient = null;
      aigcClient = null;
      isInitialized = false;
      
      debugPrint('RTC引擎已清理');
    } catch (e) {
      debugPrint('清理RTC引擎时出错: $e');
    }
  }
} 