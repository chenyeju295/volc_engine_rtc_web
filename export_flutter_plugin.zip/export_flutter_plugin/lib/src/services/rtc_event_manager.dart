import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'package:rtc_aigc_plugin/src/utils/web_utils.dart';

/// Manages RTC events and state changes
class RtcEventManager {
  final RtcConfig config;
  dynamic _rtcClient;
  
  // Stream controllers
  final StreamController<Map<String, dynamic>> _stateController = 
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<String> _connectionStateController = 
      StreamController<String>.broadcast();
  final StreamController<Map<String, dynamic>> _errorController = 
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<List<dynamic>> _audioDevicesController =
      StreamController<List<dynamic>>.broadcast();
  
  // State tracking
  bool _isAIThinking = false;
  bool _isAITalking = false;
  String _connectionState = 'disconnected';
  
  // Streams
  Stream<Map<String, dynamic>> get stateStream => _stateController.stream;
  Stream<String> get connectionStream => _connectionStateController.stream;
  Stream<Map<String, dynamic>> get errorStream => _errorController.stream;
  Stream<List<dynamic>> get audioDevicesStream => _audioDevicesController.stream;
  
  // Getters for current state
  bool get isAIThinking => _isAIThinking;
  bool get isAITalking => _isAITalking;
  String get connectionState => _connectionState;
  
  RtcEventManager({required this.config});
  
  void setEngine(dynamic rtcClient) {
    _rtcClient = rtcClient;
  }
  
  /// 处理用户加入事件
  void handleUserJoined(dynamic userData) {
    try {
      final userId = userData is Map ? userData['userId']?.toString() : userData?.toString();
      final userName = userData is Map ? userData['userName']?.toString() : null;
      
      debugPrint('【事件】用户加入: $userId, 名称: ${userName ?? "unknown"}');
      
      // 检查是否是AI加入
      if (userId == 'BotName001' || 
          userId == 'RobotMan_' || 
          (userId?.toString() ?? '').contains('bot')) {
        debugPrint('【事件】AI用户已加入');
        _updateConnectionState('connected');
      }
    } catch (e) {
      debugPrint('【事件】处理用户加入事件失败: $e');
    }
  }
  
  /// 处理用户离开事件
  void handleUserLeft(dynamic userData) {
    try {
      final userId = userData is Map ? userData['userId']?.toString() : userData?.toString();
      final reason = userData is Map ? userData['reason']?.toString() : null;
      
      debugPrint('【事件】用户离开: $userId, 原因: ${reason ?? "unknown"}');
      
      // 检查是否是AI离开
      if (userId == 'BotName001' || 
          userId == 'RobotMan_' || 
          (userId?.toString() ?? '').contains('bot')) {
        debugPrint('【事件】AI用户已离开');
        _updateAIState('FINISHED', 'AI用户已离开');
      }
    } catch (e) {
      debugPrint('【事件】处理用户离开事件失败: $e');
    }
  }
  
  /// 处理AI状态变化
  void handleAIStateChange(String stateCode, String description) {
    debugPrint('【AI状态】AI状态更新: $stateCode - $description');

    switch (stateCode) {
      case 'THINKING':
        _isAIThinking = true;
        _isAITalking = false;
        debugPrint('【AI状态】AI开始思考');
        break;
      case 'SPEAKING':
        _isAIThinking = false;
        _isAITalking = true;
        debugPrint('【AI状态】AI开始说话');
        break;
      case 'LISTENING':
        _isAIThinking = false;
        _isAITalking = false;
        debugPrint('【AI状态】AI开始聆听');
        break;
      case 'FINISHED':
      case 'INTERRUPTED':
        _isAIThinking = false;
        _isAITalking = false;
        debugPrint('【AI状态】AI已${stateCode == 'FINISHED' ? '完成' : '被打断'}');
        break;
    }

    // 发送状态更新
    final stateMap = {
      'state': stateCode,
      'description': description,
      'isThinking': _isAIThinking,
      'isTalking': _isAITalking,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    };

    _stateController.add(stateMap);
  }
  
  /// 根据整数状态码更新AI状态
  void updateAIStateFromCode(int stateCode, String description) {
    final stateString = _getStateStringFromCode(stateCode);
    handleAIStateChange(stateString, description);
  }
  
  /// 获取状态码对应的字符串
  String _getStateStringFromCode(int code) {
    switch (code) {
      case 1: return 'LISTENING';
      case 2: return 'THINKING';
      case 3: return 'SPEAKING';
      case 4: return 'INTERRUPTED';
      case 5: return 'FINISHED';
      default: return 'UNKNOWN';
    }
  }
  
  /// 处理用户开始音频采集事件
  void handleUserStartAudioCapture(dynamic userData) {
    try {
      final userId = userData is Map ? userData['userId']?.toString() : userData?.toString();
      debugPrint('【事件】用户开始音频采集: $userId');

      if (userId == 'BotName001' || 
          userId == 'RobotMan_' || 
          (userId?.toString() ?? '').contains('bot')) {
        _updateAIState('SPEAKING', 'AI开始说话');
      }
    } catch (e) {
      debugPrint('【事件】处理用户开始音频采集事件失败: $e');
    }
  }
  
  /// 处理用户停止音频采集事件
  void handleUserStopAudioCapture(dynamic userData) {
    try {
      final userId = userData is Map ? userData['userId']?.toString() : userData?.toString();
      debugPrint('【事件】用户停止音频采集: $userId');

      if (userId == 'BotName001' || 
          userId == 'RobotMan_' || 
          (userId?.toString() ?? '').contains('bot')) {
        _updateAIState('FINISHED', 'AI停止说话');
      }
    } catch (e) {
      debugPrint('【事件】处理用户停止音频采集事件失败: $e');
    }
  }
  
  /// 处理自动播放失败事件
  void handleAutoPlayFailed(dynamic errorData) {
    try {
      debugPrint('【事件】自动播放失败: $errorData');
      
      _notifyAutoplayFailed();
    } catch (e) {
      debugPrint('【事件】处理自动播放失败事件失败: $e');
    }
  }
  
  /// 通知UI层自动播放失败
  void _notifyAutoplayFailed() {
    _updateConnectionState('autoplay_failed');
    
    _errorController.add({
      'code': 'AUTOPLAY_FAILED',
      'message': '音频自动播放失败，需要用户交互',
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }
  
  /// 更新连接状态
  void _updateConnectionState(String state) {
    if (_connectionState != state) {
      _connectionState = state;
      _connectionStateController.add(state);
      debugPrint('【连接状态】已更新为: $state');
    }
  }
  
  /// 更新AI状态
  void _updateAIState(String state, String description) {
    handleAIStateChange(state, description);
  }
  
  /// 报告对话状态
  void reportConversationState({required bool active, String? taskId}) {
    final stateMap = {
      'type': active ? 'task_started' : 'task_stopped',
      'taskId': taskId,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    };
    
    _stateController.add(stateMap);
    debugPrint('【对话状态】对话${active ? '开始' : '结束'}, 任务ID: $taskId');
  }
  
  /// 释放资源
  Future<void> dispose() async {
    try {
      await _stateController.close();
      await _connectionStateController.close();
      await _errorController.close();
      await _audioDevicesController.close();
      
      debugPrint('RTC事件管理器已清理');
    } catch (e) {
      debugPrint('清理RTC事件管理器时出错: $e');
    }
  }
} 