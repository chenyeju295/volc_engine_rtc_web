import 'dart:async';
import 'dart:js' as js;
import 'dart:js_util' as js_util;
import 'dart:math';
import 'dart:html' as html;

import 'package:flutter/foundation.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'package:rtc_aigc_plugin/src/utils/web_utils.dart';

/// Manages audio and video devices
class RtcDeviceManager {
  final RtcConfig config;
  dynamic _rtcClient;

  // Device state
  String? _selectedAudioInputId;
  String? _selectedAudioOutputId;
  bool _isMicrophoneActive = false;
  bool _isCameraActive = false;

  // Stream controllers
  final StreamController<bool> _audioStatusController =
      StreamController<bool>.broadcast();
  final StreamController<bool> _deviceStateController =
      StreamController<bool>.broadcast();
  final StreamController<Map<String, List<Map<String, String>>>>
      _deviceChangeController =
      StreamController<Map<String, List<Map<String, String>>>>.broadcast();

  // Streams
  Stream<bool> get audioStatusStream => _audioStatusController.stream;
  Stream<bool> get deviceStateStream => _deviceStateController.stream;
  Stream<Map<String, List<Map<String, String>>>> get deviceChangeStream =>
      _deviceChangeController.stream;

  RtcDeviceManager({required this.config});

  void setEngine(dynamic rtcClient) {
    _rtcClient = rtcClient;
    _enumerateAudioDevices();
  }

  /// 枚举音频设备
  Future<void> _enumerateAudioDevices() async {
    try {
      final devices =
          await html.window.navigator.mediaDevices?.enumerateDevices();

      if (devices != null) {
        final audioInputDevices =
            devices.where((d) => d.kind == 'audioinput').toList();
        final audioOutputDevices =
            devices.where((d) => d.kind == 'audiooutput').toList();

        debugPrint('【设备】找到 ${audioInputDevices.length} 个音频输入设备');
        debugPrint('【设备】找到 ${audioOutputDevices.length} 个音频输出设备');

        // 格式化设备信息为Map格式
        final List<Map<String, dynamic>> inputDeviceMaps =
            audioInputDevices.map((device) {
          return {
            'deviceId': device.deviceId,
            'label': device.label.isNotEmpty
                ? device.label
                : 'Microphone ${device.deviceId.substring(0, min<int>(5, device.deviceId.length))}...',
          };
        }).toList();

        final List<Map<String, dynamic>> outputDeviceMaps =
            audioOutputDevices.map((device) {
          return {
            'deviceId': device.deviceId,
            'label': device.label.isNotEmpty
                ? device.label
                : 'Speaker ${device.deviceId.substring(0, min<int>(5, device.deviceId.length))}...',
          };
        }).toList();

        // 发送设备列表到流
        _deviceChangeController.add({
          'inputDevices': inputDeviceMaps.map((device) => {
                'deviceId': device['deviceId'] as String,
                'label': device['label'] as String,
              }).toList(),
          'outputDevices': outputDeviceMaps.map((device) => {
                'deviceId': device['deviceId'] as String,
                'label': device['label'] as String,
              }).toList(),
        });
      }
    } catch (e) {
      debugPrint('【设备】枚举音频设备失败: $e');
    }
  }

  /// 获取音频输入设备列表
  Future<List<Map<String, String>>> getAudioInputDevices() async {
    try {
      final devices =
          await html.window.navigator.mediaDevices?.enumerateDevices();

      if (devices != null) {
        final List<Map<String, String>> audioInputDevices =
            devices.where((d) => d.kind == 'audioinput').map((device) {
          final String deviceId = device.deviceId;
          final String label = device.label.isNotEmpty
              ? device.label
              : 'Microphone ${deviceId.length > 5 ? deviceId.substring(0, 5) : deviceId}...';

          return <String, String>{
            'deviceId': deviceId,
            'label': label,
          };
        }).toList();

        return audioInputDevices;
      }
    } catch (e) {
      debugPrint('【设备】获取音频输入设备失败: $e');
    }

    return [];
  }

  /// 获取音频输出设备列表
  Future<List<Map<String, String>>> getAudioOutputDevices() async {
    try {
      // 使用HTML API直接获取设备
      final List<dynamic> devices =
          await html.window.navigator.mediaDevices?.enumerateDevices() ?? [];

      final audioOutputs =
          devices.where((device) => device.kind == 'audiooutput').toList();

      debugPrint('【设备】找到 ${audioOutputs.length} 个音频输出设备');

      return audioOutputs.map((device) {
        return {
          'deviceId': device.deviceId.toString(),
          'label': device.label.isNotEmpty
              ? device.label.toString()
              : 'Speaker ${device.deviceId.toString().substring(0, min<int>(4, device.deviceId.toString().length))}...',
        };
      }).toList();
    } catch (e) {
      debugPrint('【设备】枚举音频输出设备失败: $e');
      return [];
    }
  }

  /// 设置音频采集设备
  Future<bool> setAudioCaptureDevice(String deviceId) async {
    if (_rtcClient == null) return false;

    try {
      // 先保存设备ID
      _selectedAudioInputId = deviceId;

      // 调用SDK方法设置音频采集设备
      WebUtils.safeJsCall(_rtcClient, 'setAudioCaptureDevice', [deviceId]);

      debugPrint('【设备】已设置音频采集设备: $deviceId');
      return true;
    } catch (e) {
      debugPrint('【设备】设置音频采集设备失败: $e');
      return false;
    }
  }

  /// 设置音频播放设备
  Future<bool> setAudioPlaybackDevice(String deviceId) async {
    if (_rtcClient == null) return false;

    try {
      // 先保存设备ID
      _selectedAudioOutputId = deviceId;

      // 调用SDK方法设置音频播放设备
      WebUtils.safeJsCall(_rtcClient, 'setAudioPlaybackDevice', [deviceId]);

      debugPrint('【设备】已设置音频播放设备: $deviceId');
      return true;
    } catch (e) {
      debugPrint('【设备】设置音频播放设备失败: $e');
      return false;
    }
  }

  /// 获取当前使用的音频采集设备ID
  String? getCurrentAudioInputDeviceId() {
    return _selectedAudioInputId;
  }

  /// 获取当前使用的音频播放设备ID
  String? getCurrentAudioOutputDeviceId() {
    return _selectedAudioOutputId;
  }

  /// 开始音频采集
  Future<bool> startAudioCapture([String? deviceId]) async {
    if (_rtcClient == null) return false;

    try {
      // 调用JS方法
      WebUtils.safeJsCall(
          _rtcClient, 'startAudioCapture', deviceId != null ? [deviceId] : []);

      _isMicrophoneActive = true;
      if (deviceId != null) {
        _selectedAudioInputId = deviceId;
      }

      debugPrint('【设备】开始音频采集${deviceId != null ? " 使用设备: $deviceId" : ""}');
      return true;
    } catch (e) {
      debugPrint('【设备】开始音频采集失败: $e');
      return false;
    }
  }

  /// 停止音频采集
  Future<bool> stopAudioCapture() async {
    if (_rtcClient == null) return true;
    if (!_isMicrophoneActive) return true;

    try {
      // 调用JS方法
      WebUtils.safeJsCall(_rtcClient, 'stopAudioCapture', []);

      _isMicrophoneActive = false;
      debugPrint('【设备】停止音频采集');
      return true;
    } catch (e) {
      debugPrint('【设备】停止音频采集失败 (继续处理): $e');
      _isMicrophoneActive = false;
      return true; // 即使失败，也返回成功以继续执行流程
    }
  }

  /// 恢复音频播放 - 与web demo的resumeAudio方法保持一致
  Future<bool> resumeAudioPlayback() async {
    try {
      debugPrint('【音频播放】尝试手动恢复音频播放...');

      // 设置一个标记，等待JS回调
      Completer<bool> resumeCompleter = Completer<bool>();

      // 注册一次性回调函数，当JS层成功恢复音频时会触发
      js.context['onAudioResumed'] = js.allowInterop(() {
        debugPrint('【音频播放】收到音频恢复成功回调');
        if (!resumeCompleter.isCompleted) {
          resumeCompleter.complete(true);
        }
      });

      // 调用JS方法手动恢复音频
      final result = WebUtils.safeJsCall(_rtcClient, 'resumeAudio', []);
      debugPrint('【音频播放】JS返回恢复结果: $result');

      // 等待回调或超时
      bool success = false;
      try {
        success = await resumeCompleter.future.timeout(
          const Duration(seconds: 3),
          onTimeout: () {
            debugPrint('【音频播放】等待音频恢复回调超时');
            return false;
          },
        );
      } on Exception catch (e) {
        debugPrint('【音频播放】等待音频恢复回调异常: $e');
        success = false;
      }

      // 如果成功恢复音频，发送通知
      if (success) {
        debugPrint('【音频播放】音频播放已手动恢复成功');
        _audioStatusController.add(true);
      } else {
        debugPrint('【音频播放】音频播放未能手动恢复');
      }

      return success;
    } catch (e) {
      debugPrint('【音频播放】手动恢复音频播放失败: $e');
      return false;
    }
  }

  /// 请求麦克风权限
  Future<bool> requestMicrophoneAccess() async {
    if (_isMicrophoneActive) return true;
    if (_rtcClient == null) return false;

    try {
      // 直接使用HTML5 API获取音频权限
      final constraints = {'audio': true, 'video': false};

      // 先获取权限
      final stream =
          await html.window.navigator.mediaDevices?.getUserMedia(constraints);
      if (stream == null) {
        debugPrint('【设备】无法获取麦克风权限');
        return false;
      }

      // 获取设备列表
      final audioInputs = await getAudioInputDevices();
      if (audioInputs.isEmpty) {
        debugPrint('【设备】没有找到可用的麦克风设备');
        // 停止流并返回
        stream.getTracks().forEach((track) => track.stop());
        return false;
      }

      // 获取第一个可用的设备ID
      final deviceId = audioInputs.first['deviceId'];
      if (deviceId == null || deviceId.isEmpty) {
        debugPrint('【设备】设备ID无效');
        // 停止流并返回
        stream.getTracks().forEach((track) => track.stop());
        return false;
      }

      // 停止获取权限时使用的流
      stream.getTracks().forEach((track) => track.stop());

      // 直接调用startAudioCapture方法
      final result = await startAudioCapture(deviceId);
      if (result) {
        _selectedAudioInputId = deviceId;
        _isMicrophoneActive = true;
        debugPrint('【设备】麦克风访问成功，使用设备: $deviceId');
        return true;
      } else {
        debugPrint('【设备】启动音频采集失败');
        return false;
      }
    } catch (e) {
      debugPrint('【设备】请求麦克风访问失败: $e');
      return false;
    }
  }

  /// 请求摄像头权限
  Future<bool> requestCameraAccess() async {
    if (_isCameraActive) return true;
    if (_rtcClient == null) return false;

    try {
      final constraints = {
        'video': true,
      };

      final stream =
          await html.window.navigator.mediaDevices?.getUserMedia(constraints);

      if (stream != null) {
        // 使用WebUtils确保安全调用JS方法
        WebUtils.safeJsCall(_rtcClient, 'setLocalVideoStream', [stream]);
        _isCameraActive = true;
        // 只是检查权限，停止流
        stream.getTracks().forEach((track) => track.stop());
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('【设备】请求摄像头访问失败: $e');
      return false;
    }
  }

  Future<void> dispose() async {
    try {
      if (_isMicrophoneActive) {
        await stopAudioCapture();
      }

      await _audioStatusController.close();
      await _deviceStateController.close();
      await _deviceChangeController.close();

      debugPrint('RTC设备管理器已清理');
    } catch (e) {
      debugPrint('清理RTC设备管理器时出错: $e');
    }
  }
}
