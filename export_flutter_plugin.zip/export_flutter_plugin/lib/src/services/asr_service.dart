import 'dart:async';
import 'dart:html' as html;
import 'dart:js' as js;
import 'dart:typed_data';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:flutter/foundation.dart';
import '../config/config.dart';
import '../utils/web_utils.dart';
import 'service_interface.dart';
import '../client/aigc_client.dart';

/// Callback for speech recognition results
typedef SpeechRecognizedCallback = void Function(String text, bool isFinal);

/// ASR (Automatic Speech Recognition) service
class AsrService implements Service {
  /// Configuration for the ASR service
  final AsrConfig? config;
  
  /// Server URL for communication with ASR service
  final String? serverUrl;
  
  /// HTTP client
  final http.Client _httpClient = http.Client();

  /// Callback for speech recognition events
  SpeechRecognizedCallback? onSpeechRecognized;

  /// Stream controller for recognition results
  final StreamController<String> _recognitionResultController =
      StreamController<String>.broadcast();

  /// Is recognition currently active
  bool _isRecognizing = false;

  /// Media stream from microphone
  html.MediaStream? _microphoneStream;
  
  /// 音频上下文 - 使用JS互操作而非强类型
  js.JsObject? _audioContext;
  
  /// 脚本处理节点
  js.JsObject? _scriptProcessor;
  
  /// 音频源节点
  js.JsObject? _sourceNode;
  
  /// Audio recorder settings
  final int _sampleRate = 16000;
  final int _channels = 1;
  
  /// 当前会话ID
  String? _sessionId;
  
  /// 语音识别的临时结果
  String _currentRecognitionText = '';
  
  /// 音频缓冲区 - 用于收集足够数据后再发送
  final List<Int16List> _audioBuffers = [];
  
  /// 音频数据大小阈值 - 当收集到足够数据时发送 (16KB)
  final int _audioBufferThreshold = 16 * 1024;
  
  /// 当前缓冲区大小
  int _currentBufferSize = 0;
  
  /// 静音检测 - 静音开始时间 (毫秒)
  int? _silenceStartTime;
  
  /// 静音检测 - 静音阈值 (0-32767之间)
  final int _silenceThreshold = 500;
  
  /// 静音检测 - 认为是静音的持续时间 (毫秒)
  final int _silenceDuration = 1500;

  /// AIGC client for API requests
  AigcClient? client;

  /// ASR service for speech recognition
  AsrService({
    this.config,
    this.onSpeechRecognized,
    this.serverUrl,
    AigcClient? client,
  }) {
    this.client = client;
  }

  /// Stream of recognition results
  Stream<String> get recognitionResultStream => _recognitionResultController.stream;

  /// Is currently recognizing speech
  bool get isRecognizing => _isRecognizing;

  /// Set result callback
  void setResultCallback(SpeechRecognizedCallback callback) {
    onSpeechRecognized = callback;
  }
  
  /// Set state change callback
  void setStateChangeCallback(Function(String state) callback) {
    // 实现状态变化回调
    _stateChangeCallback = callback;
  }
  
  /// Callback for state changes
  Function(String state)? _stateChangeCallback;

  @override
  Future<void> initialize() async {
    try {
      // 确认配置有效性
      if (config == null || config!.appId.isEmpty) {
        debugPrint('[AsrService] 警告: ASR配置不完整');
      }
      
      debugPrint('[AsrService] 初始化完成');
    } catch (e) {
      debugPrint('[AsrService] 初始化失败: $e');
      rethrow;
    }
  }

  /// 生成唯一会话ID
  String _generateSessionId() {
    return 'asr_${DateTime.now().millisecondsSinceEpoch}_${(1000 + (1000 * DateTime.now().millisecondsSinceEpoch) % 9000).toInt()}';
  }

  /// Start speech recognition
  Future<bool> startRecognition() async {
    if (_isRecognizing) {
      debugPrint('[AsrService] 语音识别已经在运行中');
      return true;
    }

    try {
      // 重置状态
      _audioBuffers.clear();
      _currentBufferSize = 0;
      _silenceStartTime = null;
      _currentRecognitionText = '';
      
      // 生成新会话ID
      _sessionId = _generateSessionId();
      
      // 初始化音频流
      await _initAudioStream();
      
      // 开始录音
      await _startAudioCapture();
      
      _isRecognizing = true;
      debugPrint('[AsrService] 语音识别已启动，会话ID: $_sessionId');
      return true;
    } catch (e) {
      debugPrint('[AsrService] 启动语音识别失败: $e');
      await _cleanupAudioResources();
      return false;
    }
  }

  /// 初始化音频流和相关资源
  Future<void> _initAudioStream() async {
    try {
      // 请求麦克风权限
      _microphoneStream = await html.window.navigator.mediaDevices?.getUserMedia({
        'audio': {
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
        }
      });

      if (_microphoneStream == null) {
        throw Exception('无法获取麦克风权限');
      }
      
      debugPrint('[AsrService] 已获取麦克风权限');
      
      // 使用JS互操作创建音频上下文和处理节点
      if (js.context.hasProperty('AudioContext')) {
        _audioContext = js.JsObject(js.context['AudioContext']);
      } else if (js.context.hasProperty('webkitAudioContext')) {
        _audioContext = js.JsObject(js.context['webkitAudioContext']);
      } else {
        throw Exception('浏览器不支持Web Audio API');
      }
      
      debugPrint('[AsrService] 音频上下文创建成功');
      
      // 创建源节点
      _sourceNode = _audioContext!.callMethod('createMediaStreamSource', [_microphoneStream]);
      
      // 创建处理节点 - 使用较大的缓冲区大小减少处理次数，提高性能
      _scriptProcessor = _audioContext!.callMethod('createScriptProcessor', [4096, _channels, _channels]);
      
      // 设置数据处理事件
      _scriptProcessor!['onaudioprocess'] = js.allowInterop((event) {
        _handleAudioProcess(event);
      });
      
      // 连接节点
      _sourceNode!.callMethod('connect', [_scriptProcessor]);
      _scriptProcessor!.callMethod('connect', [_audioContext!['destination']]);
      
      debugPrint('[AsrService] 音频处理管道设置完成');
      
    } catch (e) {
      debugPrint('[AsrService] 初始化音频流失败: $e');
      await _cleanupAudioResources();
      rethrow;
    }
  }

  /// 处理音频数据
  void _handleAudioProcess(dynamic event) {
    try {
      if (!_isRecognizing) return;
      
      // 从JS对象提取音频数据
      js.JsObject inputBuffer = event['inputBuffer'];
      js.JsObject channelData = inputBuffer.callMethod('getChannelData', [0]);
      
      // 转换为Float32List
      final int bufferLength = inputBuffer['length'];
      Float32List float32Data = Float32List(bufferLength);
      for (int i = 0; i < bufferLength; i++) {
        float32Data[i] = channelData[i];
      }
      
      // 转换为Int16
      Int16List pcmData = _float32ToInt16(float32Data);
      
      // 检查是否是静音
      bool isSilence = _detectSilence(pcmData);
      
      // 添加到缓冲区
      _audioBuffers.add(pcmData);
      _currentBufferSize += pcmData.lengthInBytes;
      
      // 当缓冲区达到阈值或静音结束时发送数据
      if (_currentBufferSize >= _audioBufferThreshold || 
          (isSilence && _silenceStartTime != null && 
           DateTime.now().millisecondsSinceEpoch - _silenceStartTime! >= _silenceDuration)) {
        _sendBufferedAudioData();
      }
      
    } catch (e) {
      debugPrint('[AsrService] 处理音频数据错误: $e');
    }
  }
  
  /// 发送缓冲的音频数据
  void _sendBufferedAudioData() {
    if (_audioBuffers.isEmpty) return;
    
    // 合并所有音频缓冲区
    final int totalLength = _currentBufferSize ~/ 2; // 每个Int16占2字节
    final Int16List combinedData = Int16List(totalLength);
    
    int offset = 0;
    for (var buffer in _audioBuffers) {
      combinedData.setRange(offset, offset + buffer.length, buffer);
      offset += buffer.length;
    }
    
    // 发送数据到ASR服务
    _sendAudioData(Uint8List.fromList(
      combinedData.buffer.asUint8List(combinedData.offsetInBytes, combinedData.lengthInBytes)
    ));
    
    // 清空缓冲区
    _audioBuffers.clear();
    _currentBufferSize = 0;
  }
  
  /// 检测音频是否静音
  bool _detectSilence(Int16List audioData) {
    // 计算平均能量
    double sumEnergy = 0;
    for (int i = 0; i < audioData.length; i++) {
      sumEnergy += audioData[i].abs();
    }
    double avgEnergy = sumEnergy / audioData.length;
    
    // 判断是否是静音
    bool isSilence = avgEnergy < _silenceThreshold;
    
    // 更新静音开始时间
    if (isSilence) {
      if (_silenceStartTime == null) {
        _silenceStartTime = DateTime.now().millisecondsSinceEpoch;
      }
    } else {
      _silenceStartTime = null; // 重置静音计时
    }
    
    return isSilence;
  }

  /// 将Float32数据转换为Int16
  Int16List _float32ToInt16(Float32List float32Data) {
    final int length = float32Data.length;
    final Int16List int16Data = Int16List(length);
    
    for (int i = 0; i < length; i++) {
      // 将-1.0到1.0的浮点数转换为-32768到32767的整数
      int16Data[i] = (float32Data[i] * 32767.0).round().clamp(-32768, 32767);
    }
    
    return int16Data;
  }

  /// 开始采集并发送音频
  Future<void> _startAudioCapture() async {
    try {
      // 发送开始请求
      await _sendStartRequest();
      debugPrint('[AsrService] 开始采集音频');
    } catch (e) {
      debugPrint('[AsrService] 开始采集音频失败: $e');
      rethrow;
    }
  }
  
  /// 发送音频数据给ASR服务
  Future<void> _sendAudioData(Uint8List audioData) async {
    if (!_isRecognizing || audioData.isEmpty || _sessionId == null) return;
    
    try {
      // 构建请求参数
      final url = Uri.parse('${serverUrl ?? 'https://open.volcengineapi.com'}/v1/SASR');
      
      // 准备请求体
      final requestBody = {
        'AppId': config?.appId ?? '',
        'SessionId': _sessionId,
        'AudioFormat': 'pcm',
        'SampleRate': _sampleRate,
        'RequestId': '${_sessionId}_${DateTime.now().millisecondsSinceEpoch}',
        'Data': base64Encode(audioData),
      };
      
      // 添加集群信息(如果有)
      if (config?.cluster != null && config!.cluster!.isNotEmpty) {
        requestBody['Cluster'] = config!.cluster;
      }
      
      // 发送请求
      final response = await _httpClient.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestBody),
      );
      
      if (response.statusCode == 200) {
        // 解析响应
        final responseData = jsonDecode(response.body);
        await _handleRecognitionResult(responseData);
      } else {
        debugPrint('[AsrService] ASR API错误: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      debugPrint('[AsrService] 发送音频数据错误: $e');
    }
  }
  
  /// 发送开始请求到ASR服务
  Future<void> _sendStartRequest() async {
    try {
      // 构建请求参数
      final url = Uri.parse('${serverUrl ?? 'https://open.volcengineapi.com'}/v1/ASRStart');
      
      // 准备请求体
      final requestBody = {
        'AppId': config?.appId ?? '',
        'SessionId': _sessionId,
        'AudioFormat': 'pcm',
        'SampleRate': _sampleRate,
        'RequestId': '${_sessionId}_start_${DateTime.now().millisecondsSinceEpoch}',
      };
      
      // 添加集群信息(如果有)
      if (config?.cluster != null && config!.cluster!.isNotEmpty) {
        requestBody['Cluster'] = config!.cluster;
      }
      
      // 添加VAD配置(如果有)
      requestBody['VADConfig'] = {
        'SilenceTime': 600, // 静音检测时间(毫秒)
        'SilenceThreshold': 200, // 静音阈值
      };
      
      // 发送请求
      final response = await _httpClient.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestBody),
      );
      
      if (response.statusCode != 200) {
        debugPrint('[AsrService] ASR启动API错误: ${response.statusCode} - ${response.body}');
      } else {
        debugPrint('[AsrService] ASR会话启动成功');
      }
    } catch (e) {
      debugPrint('[AsrService] 发送启动请求错误: $e');
      rethrow;
    }
  }
  
  /// 处理识别结果
  Future<void> _handleRecognitionResult(Map<String, dynamic> response) async {
    try {
      // 检查响应状态
      if (response['ResponseMetadata'] != null && 
          response['ResponseMetadata']['Error'] != null) {
        final error = response['ResponseMetadata']['Error'];
        debugPrint('[AsrService] ASR API错误: ${error['Code']} - ${error['Message']}');
        return;
      }
      
      // 检查是否包含识别结果
      if (response['Data'] != null && response['Data'] is Map) {
        final data = response['Data'];
        
        // 获取文本和最终状态
        String text = data['Text'] ?? '';
        final bool isFinal = data['Status'] == 'final';
        
        // 如果是中间结果或最终结果，更新当前文本
        if (text.isNotEmpty) {
          _currentRecognitionText = text;
          debugPrint('[AsrService] 识别结果: $_currentRecognitionText (${isFinal ? "最终" : "中间"})');
        }
        
        // 调用回调
        if (onSpeechRecognized != null) {
          onSpeechRecognized!(_currentRecognitionText, isFinal);
        }
        
        // 如果是最终结果，发送到流
        if (isFinal && !_recognitionResultController.isClosed && _currentRecognitionText.isNotEmpty) {
          _recognitionResultController.add(_currentRecognitionText);
          _currentRecognitionText = ''; // 重置当前文本
        }
      }
    } catch (e) {
      debugPrint('[AsrService] 处理ASR响应错误: $e');
    }
  }

  /// 发送音频数据到ASR服务 (外部调用)
  void sendAudioData(Uint8List audioData, {int? sampleRate}) {
    if (!_isRecognizing) return;
    
    _sendAudioData(audioData);
  }

  /// 停止语音识别
  Future<void> stopRecognition() async {
    if (!_isRecognizing) return;

    try {
      // 发送缓冲区剩余数据
      _sendBufferedAudioData();
      
      // 发送停止请求
      await _sendStopRequest();
      
      // 清理资源
      await _cleanupAudioResources();
      
      // 设置状态
      _isRecognizing = false;
      
      // 如果有未提交的最终文本，发送它
      if (!_recognitionResultController.isClosed && _currentRecognitionText.isNotEmpty) {
        _recognitionResultController.add(_currentRecognitionText);
        _currentRecognitionText = '';
      }

      debugPrint('[AsrService] 语音识别已停止');
    } catch (e) {
      debugPrint('[AsrService] 停止语音识别失败: $e');
    }
  }
  
  /// 发送停止请求到ASR服务
  Future<void> _sendStopRequest() async {
    if (_sessionId == null) return;
    
    try {
      // 构建请求参数
      final url = Uri.parse('${serverUrl ?? 'https://open.volcengineapi.com'}/v1/ASRStop');
      
      // 准备请求体
      final requestBody = {
        'AppId': config?.appId ?? '',
        'SessionId': _sessionId,
        'RequestId': '${_sessionId}_stop_${DateTime.now().millisecondsSinceEpoch}',
      };
      
      // 添加集群信息(如果有)
      if (config?.cluster != null && config!.cluster!.isNotEmpty) {
        requestBody['Cluster'] = config!.cluster;
      }
      
      // 发送请求
      final response = await _httpClient.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestBody),
      );
      
      if (response.statusCode != 200) {
        debugPrint('[AsrService] ASR停止API错误: ${response.statusCode} - ${response.body}');
      } else {
        debugPrint('[AsrService] ASR会话停止成功');
      }
    } catch (e) {
      debugPrint('[AsrService] 发送停止请求错误: $e');
    }
  }

  /// 清理音频资源
  Future<void> _cleanupAudioResources() async {
    // 断开节点连接
    if (_scriptProcessor != null && _sourceNode != null) {
      try {
        _sourceNode!.callMethod('disconnect');
        _scriptProcessor!.callMethod('disconnect');
      } catch (e) {
        debugPrint('[AsrService] 断开音频节点连接错误: $e');
      }
    }
    
    // 关闭音频上下文
    if (_audioContext != null) {
      try {
        _audioContext!.callMethod('close');
        _audioContext = null;
      } catch (e) {
        debugPrint('[AsrService] 关闭音频上下文错误: $e');
      }
    }
    
    // 停止麦克风流
    if (_microphoneStream != null) {
      try {
        _microphoneStream!.getTracks().forEach((track) => track.stop());
        _microphoneStream = null;
      } catch (e) {
        debugPrint('[AsrService] 停止麦克风流错误: $e');
      }
    }
    
    // 清理引用
    _sourceNode = null;
    _scriptProcessor = null;
  }

  @override
  Future<void> dispose() async {
    await stopRecognition();
    
    // 关闭HTTP客户端
    _httpClient.close();

    // 关闭流控制器
    if (!_recognitionResultController.isClosed) {
      await _recognitionResultController.close();
    }

    debugPrint('[AsrService] ASR服务已释放');
  }
}
