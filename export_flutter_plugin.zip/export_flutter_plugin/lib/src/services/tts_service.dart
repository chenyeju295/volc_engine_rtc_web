import 'dart:async';
import 'dart:convert';
import 'dart:html' as html;
import 'dart:typed_data';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/config.dart';
import 'service_interface.dart';
import '../client/aigc_client.dart';

/// Callback for speech state changes
typedef SpeechStateCallback = void Function(bool isActive);

/// TTS (Text-to-Speech) service
class TtsService implements Service {
  /// Configuration for the TTS service
  final TtsConfig? config;

  /// Callback for speech state changes
  final SpeechStateCallback? onSpeechStateChanged;

  /// Stream controller for speech state
  final StreamController<bool> _speechStateController =
      StreamController<bool>.broadcast();

  /// HTTP client
  final http.Client _httpClient = http.Client();

  /// Audio element for playing speech
  html.AudioElement? _audioElement;

  /// Is speech currently active
  bool _isSpeaking = false;

  /// Audio cache - maps text to audio URL
  final Map<String, String> _audioCache = {};
  
  /// 最大缓存条目数
  final int _maxCacheEntries = 20;
  
  /// 缓存访问顺序 - 用于LRU缓存策略
  final List<String> _cacheAccessOrder = [];

  /// Blob URLs to be revoked on dispose
  final List<String> _blobUrls = [];
  
  /// 播放完成Promise
  Completer<void>? _playbackCompleter;
  
  /// 播放队列
  final List<_TtsQueueItem> _playbackQueue = [];
  
  /// 是否正在处理队列
  bool _isProcessingQueue = false;

  /// AIGC client for API requests
  AigcClient? client;

  /// TTS service for text-to-speech conversion
  TtsService({
    this.config,
    this.onSpeechStateChanged,
  });

  /// Stream of speech state changes
  Stream<bool> get speechState => _speechStateController.stream;

  /// Is currently speaking
  bool get isSpeaking => _isSpeaking;
  
  /// Is TTS service initialized
  bool get isInitialized => _audioElement != null;
  
  /// Set playback start callback
  void setPlaybackStartCallback(Function() callback) {
    _audioElement?.onPlay.listen((_) {
      callback();
    });
  }
  
  /// Set playback complete callback
  void setPlaybackCompleteCallback(Function() callback) {
    _audioElement?.onEnded.listen((_) {
      callback();
    });
  }

  @override
  Future<void> initialize() async {
    try {
      // 检查配置
      if (config == null || config!.appId.isEmpty) {
        debugPrint('[TtsService] 警告: TTS配置不完整');
      }
      
      // Create audio element
      _audioElement = html.AudioElement();
      
      // Set up audio element listeners
      _setupAudioListeners();
      
      debugPrint('[TtsService] TTS服务初始化成功');
    } catch (e) {
      debugPrint('[TtsService] 初始化TTS服务失败: $e');
      rethrow;
    }
  }

  /// Set up audio element listeners
  void _setupAudioListeners() {
    _audioElement?.onEnded.listen((_) {
      _onPlaybackEnded();
      debugPrint('[TtsService] 播放完成');
    });

    _audioElement?.onError.listen((event) {
      _onPlaybackEnded(error: true);
      debugPrint('[TtsService] 播放错误: ${event.toString()}');
    });
    
    _audioElement?.onPlay.listen((_) {
      debugPrint('[TtsService] 开始播放');
    });
    
    _audioElement?.onPause.listen((_) {
      debugPrint('[TtsService] 暂停播放');
    });
  }
  
  /// 播放完成或出错时调用
  void _onPlaybackEnded({bool error = false}) {
    _isSpeaking = false;
    _speechStateController.add(false);
    if (onSpeechStateChanged != null) {
      onSpeechStateChanged!(false);
    }
    
    // 完成当前播放Promise
    if (_playbackCompleter != null && !_playbackCompleter!.isCompleted) {
      if (error) {
        _playbackCompleter!.completeError('播放错误');
      } else {
        _playbackCompleter!.complete();
      }
      _playbackCompleter = null;
    }
    
    // 处理队列中的下一项
    _processNextInQueue();
  }
  
  /// 处理队列中的下一项
  Future<void> _processNextInQueue() async {
    if (_isProcessingQueue || _playbackQueue.isEmpty) return;
    
    _isProcessingQueue = true;
    try {
      final item = _playbackQueue.removeAt(0);
      
      if (item.audioData != null) {
        await _playAudioData(item.audioData!);
      } else if (item.text != null) {
        await _speakText(item.text!);
      }
    } finally {
      _isProcessingQueue = false;
      
      // 如果队列中还有项目，继续处理
      if (_playbackQueue.isNotEmpty) {
        _processNextInQueue();
      }
    }
  }

  /// Speak the given text
  Future<void> speak(String text) async {
    if (text.isEmpty) return;
    
    // 创建一个新的Promise
    final completer = Completer<void>();
    
    // 添加到队列
    _playbackQueue.add(_TtsQueueItem(text: text));
    
    // 如果没有正在处理队列，开始处理
    if (!_isProcessingQueue && !_isSpeaking) {
      _processNextInQueue();
    }
    
    return completer.future;
  }
  
  /// 播放音频数据
  Future<void> playAudioData(Uint8List audioData) async {
    if (audioData.isEmpty) return;
    
    // 创建一个新的Promise
    final completer = Completer<void>();
    
    // 添加到队列
    _playbackQueue.add(_TtsQueueItem(audioData: audioData));
    
    // 如果没有正在处理队列，开始处理
    if (!_isProcessingQueue && !_isSpeaking) {
      _processNextInQueue();
    }
    
    return completer.future;
  }
  
  /// 内部方法：播放文本
  Future<void> _speakText(String text) async {
    if (text.isEmpty || _audioElement == null) return;

    try {
      // Stop current playback
      stopSpeaking();

      // Notify playback started
      _isSpeaking = true;
      _speechStateController.add(true);
      if (onSpeechStateChanged != null) {
        onSpeechStateChanged!(true);
      }
      
      // 创建播放Promise
      _playbackCompleter = Completer<void>();

      // Check cache
      if (_audioCache.containsKey(text)) {
        debugPrint('[TtsService] 使用缓存的音频: $text');
        
        // 更新缓存访问记录
        _updateCacheAccess(text);
        
        _audioElement!.src = _audioCache[text]!;
        await _audioElement!.play();
        return _playbackCompleter!.future;
      }

      // Build request parameters
      final params = {
        'Text': text,
        'Voice': {
          'AppId': config?.appId ?? '',
          'VoiceType': config?.voiceType ?? 'BV001_streaming', // 默认为通用女声
          'Cluster': config?.cluster ?? 'volcano_tts', // 默认火山引擎TTS集群
        },
        'Format': 'mp3', // 支持的音频格式：wav, mp3
        'SampleRate': 16000,
        'RequestId': _generateRequestId(),
        'EnableRealTimeTTS': true,
      };
      
      // 若有更多配置参数，添加
      if (config?.ignoreBracketText != null) {
        params['IgnoreBracketText'] = config!.ignoreBracketText! ? 1 : 0;
      }

      // Send TTS request
      final audioData = await _sendTtsRequest(params);
      
      // 如果播放已被取消，不继续
      if (_playbackCompleter == null || _playbackCompleter!.isCompleted) {
        return;
      }
      
      // Create a blob URL for the audio data
      final blob = html.Blob([audioData], 'audio/mp3');
      final url = html.Url.createObjectUrlFromBlob(blob);
      _blobUrls.add(url);
      
      // Cache audio URL
      _addToCache(text, url);
      
      // Play audio
      _audioElement!.src = url;
      await _audioElement!.play();
      
      debugPrint('[TtsService] 播放文本: $text');
      
      return _playbackCompleter!.future;
    } catch (e) {
      _isSpeaking = false;
      _speechStateController.add(false);
      if (onSpeechStateChanged != null) {
        onSpeechStateChanged!(false);
      }
      
      // 完成Promise（出错）
      if (_playbackCompleter != null && !_playbackCompleter!.isCompleted) {
        _playbackCompleter!.completeError(e);
        _playbackCompleter = null;
      }
      
      debugPrint('[TtsService] 播放文本错误: $e');
      
      // 处理队列中的下一项
      _processNextInQueue();
      
      rethrow;
    }
  }
  
  /// 内部方法：播放音频数据
  Future<void> _playAudioData(Uint8List audioData) async {
    if (audioData.isEmpty || _audioElement == null) return;
    
    try {
      // 停止当前播放
      stopSpeaking();
      
      // 通知开始播放
      _isSpeaking = true;
      _speechStateController.add(true);
      if (onSpeechStateChanged != null) {
        onSpeechStateChanged!(true);
      }
      
      // 创建播放Promise
      _playbackCompleter = Completer<void>();
      
      // 创建Blob URL
      final blob = html.Blob([audioData], 'audio/mp3');
      final url = html.Url.createObjectUrlFromBlob(blob);
      _blobUrls.add(url);
      
      // 播放音频
      _audioElement!.src = url;
      await _audioElement!.play();
      
      debugPrint('[TtsService] 播放音频数据: ${audioData.length} 字节');
      
      return _playbackCompleter!.future;
    } catch (e) {
      _isSpeaking = false;
      _speechStateController.add(false);
      if (onSpeechStateChanged != null) {
        onSpeechStateChanged!(false);
      }
      
      // 完成Promise（出错）
      if (_playbackCompleter != null && !_playbackCompleter!.isCompleted) {
        _playbackCompleter!.completeError(e);
        _playbackCompleter = null;
      }
      
      debugPrint('[TtsService] 播放音频数据错误: $e');
      
      // 处理队列中的下一项
      _processNextInQueue();
      
      rethrow;
    }
  }
  
  /// 更新缓存访问记录
  void _updateCacheAccess(String text) {
    // 如果在访问顺序列表中，移除它
    _cacheAccessOrder.remove(text);
    // 添加到最新访问的位置
    _cacheAccessOrder.add(text);
  }
  
  /// 添加到缓存
  void _addToCache(String text, String url) {
    // 添加到缓存
    _audioCache[text] = url;
    // 更新访问记录
    _updateCacheAccess(text);
    
    // 如果超出最大缓存条目数，移除最早访问的
    if (_audioCache.length > _maxCacheEntries && _cacheAccessOrder.isNotEmpty) {
      final oldestKey = _cacheAccessOrder.removeAt(0);
      final oldUrl = _audioCache.remove(oldestKey);
      
      // 如果是Blob URL，撤销它
      if (oldUrl != null && _blobUrls.contains(oldUrl)) {
        html.Url.revokeObjectUrl(oldUrl);
        _blobUrls.remove(oldUrl);
      }
      
      debugPrint('[TtsService] 缓存清理: 移除了 "$oldestKey"');
    }
  }

  /// Stop speaking
  void stopSpeaking() {
    try {
      if (_audioElement != null && !_audioElement!.paused) {
        _audioElement!.pause();
        _audioElement!.currentTime = 0;
      }
      
      _isSpeaking = false;
      _speechStateController.add(false);
      if (onSpeechStateChanged != null) {
        onSpeechStateChanged!(false);
      }
      
      // 取消当前播放Promise
      if (_playbackCompleter != null && !_playbackCompleter!.isCompleted) {
        _playbackCompleter!.completeError('播放被取消');
        _playbackCompleter = null;
      }
      
      // 清空播放队列
      _playbackQueue.clear();
      _isProcessingQueue = false;
      
      debugPrint('[TtsService] 停止播放');
    } catch (e) {
      debugPrint('[TtsService] 停止播放错误: $e');
    }
  }

  /// Send TTS request to the API
  Future<Uint8List> _sendTtsRequest(Map<String, dynamic> params) async {
    // 使用火山引擎TTS API
    final url = 'https://open.volcengineapi.com/v2/TTS';
    final requestId = params['RequestId'] ?? _generateRequestId();
    
    try {
      debugPrint('[TtsService] 发送TTS请求: ${jsonEncode(params)}');
      
      final response = await _httpClient.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'X-Request-Id': requestId,
        },
        body: jsonEncode(params),
      );
      
      if (response.statusCode == 200) {
        debugPrint('[TtsService] TTS响应接收, 大小: ${response.bodyBytes.length} 字节');
        
        // 解析响应JSON
        final jsonResponse = jsonDecode(utf8.decode(response.bodyBytes));
        
        // 检查响应状态
        if (jsonResponse['ResponseMetadata'] != null && 
            jsonResponse['ResponseMetadata']['Error'] != null) {
          final error = jsonResponse['ResponseMetadata']['Error'];
          throw Exception('[TtsService] API错误: ${error['Code']} - ${error['Message']}');
        }
        
        // 提取音频数据
        if (jsonResponse['Data'] != null && jsonResponse['Data']['Data'] != null) {
          final audioBase64 = jsonResponse['Data']['Data'];
          return base64Decode(audioBase64);
        } else {
          throw Exception('[TtsService] 响应中没有音频数据');
        }
      } else {
        throw Exception('[TtsService] TTS请求失败: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('[TtsService] 发送TTS请求错误: $e');
      rethrow;
    }
  }

  /// Generate a unique request ID
  String _generateRequestId() {
    final random = Random();
    final now = DateTime.now().millisecondsSinceEpoch;
    final randomPart = random.nextInt(10000).toString().padLeft(4, '0');
    return 'tts_${now}_$randomPart';
  }

  @override
  Future<void> dispose() async {
    // Stop playback
    stopSpeaking();
    
    // Revoke all blob URLs to avoid memory leaks
    for (final url in _blobUrls) {
      html.Url.revokeObjectUrl(url);
    }
    _blobUrls.clear();
    
    // Clear cache
    _audioCache.clear();
    _cacheAccessOrder.clear();
    
    // Close http client
    _httpClient.close();
    
    // Clear audio element
    _audioElement = null;
    
    // Close stream controller
    try {
      await _speechStateController.close();
    } catch (e) {
      debugPrint('[TtsService] 关闭语音状态控制器错误: $e');
    }
    
    debugPrint('[TtsService] TTS服务已释放');
  }
}

/// TTS播放队列项
class _TtsQueueItem {
  /// 要播放的文本
  final String? text;
  
  /// 要播放的音频数据
  final Uint8List? audioData;
  
  /// 构造函数
  _TtsQueueItem({this.text, this.audioData});
}
