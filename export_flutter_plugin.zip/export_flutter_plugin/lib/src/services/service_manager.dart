import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:rtc_aigc_plugin/src/client/aigc_client.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';
import 'package:rtc_aigc_plugin/src/services/asr_service.dart';
import 'package:rtc_aigc_plugin/src/services/llm_service.dart';
import 'package:rtc_aigc_plugin/src/services/rtc_service.dart';
import 'package:rtc_aigc_plugin/src/services/tts_service.dart';

/// Callback for handling state changes
typedef StateChangeCallback = void Function(String state, String? message);

/// Callback for handling text messages
typedef MessageCallback = void Function(String message, bool isUser);

/// Callback for handling audio status changes
typedef AudioStatusCallback = void Function(bool isPlaying);

/// Manages all services for the AIGC RTC plugin
class ServiceManager {
  /// RTC service
  final RtcService _rtcService;

  /// ASR service
  final AsrService _asrService;

  /// TTS service
  final TtsService _ttsService;

  /// LLM service
  final LlmService _llmService;

  /// AIGC client for API calls
  final AigcClient _aigcClient;

  /// State change callback
  final StateChangeCallback? _onStateChange;

  /// Message callback
  final MessageCallback? _onMessage;

  /// Audio status callback
  final AudioStatusCallback? _onAudioStatusChange;

  /// Is the conversation active
  bool _isConversationActive = false;

  /// Is audio playing
  bool _isAudioPlaying = false;

  /// Is audio capture active
  bool _isCapturingAudio = false;

  /// Constructor
  ServiceManager({
    required AigcRtcConfig config,
    StateChangeCallback? onStateChange,
    MessageCallback? onMessage,
    AudioStatusCallback? onAudioStatusChange,
  })  : _onStateChange = onStateChange,
        _onMessage = onMessage,
        _onAudioStatusChange = onAudioStatusChange,
        _aigcClient = AigcClient(
          baseUrl: config.serverUrl ?? 'https://open.volcengineapi.com',
          appId: config.appId,
          userId: config.rtcConfig.userId,
          roomId: config.rtcConfig.roomId,
        ),
        _rtcService = RtcService(
          config: config.rtcConfig,
        ),
        _asrService = AsrService(
          config: config.asrConfig,
          serverUrl: config.serverUrl,
        ),
        _ttsService = TtsService(
          config: config.ttsConfig,
        ),
        _llmService = LlmService(
          config.llmConfig,
        ) {
        // 设置AigcClient给各服务
        _asrService.client = _aigcClient;
        _ttsService.client = _aigcClient;
        _llmService.client = _aigcClient;
      }

  /// Initialize all services
  Future<bool> initialize() async {
    try {
      debugPrint('Initializing ServiceManager');
      
      // RTC初始化
      await _rtcService.initialize();
      _notifyStateChange('rtc_initialized', 'RTC service initialized');

      // 设置RTC的回调
      _rtcService.setAudioStateChangeCallback((bool hasAudio) {
        debugPrint('RTC audio state changed: hasAudio=$hasAudio');
      });

      // TTS初始化
      await _ttsService.initialize();
      _notifyStateChange('tts_initialized', 'TTS service initialized');
      
      // 设置TTS的回调
      _ttsService.setPlaybackCompleteCallback(() {
        _isAudioPlaying = false;
        _notifyAudioStatusChange(false);
        _notifyStateChange('audio_stopped', 'Audio playback stopped');
      });
      
      _ttsService.setPlaybackStartCallback(() {
        _isAudioPlaying = true;
        _notifyAudioStatusChange(true);
        _notifyStateChange('audio_playing', 'Audio playback started');
      });

      // ASR初始化
      await _asrService.initialize();
      _notifyStateChange('asr_initialized', 'ASR service initialized');
      
      // 设置ASR的回调
      _asrService.setResultCallback((String text, bool isFinal) {
        if (isFinal && text.isNotEmpty) {
          _handleUserMessage(text);
        }
      });
      
      _asrService.setStateChangeCallback((String state) {
        if (state == 'listening') {
          _isCapturingAudio = true;
          _notifyStateChange('listening', 'Started listening');
        } else if (state == 'stopped') {
          _isCapturingAudio = false;
          _notifyStateChange('stopped_listening', 'Stopped listening');
        }
      });

      // LLM初始化
      await _llmService.initialize();
      _notifyStateChange('llm_initialized', 'LLM service initialized');
      
      // 设置LLM的回调
      _llmService.registerMessageCallback((String message, bool isUser) {
        _notifyMessage(message, isUser);
        
        // 如果是AI消息并且TTS已初始化，播放语音
        if (!isUser && _ttsService.isInitialized) {
          _ttsService.speak(message);
        }
      });

      debugPrint('All services initialized successfully');
      return true;
    } catch (e, stackTrace) {
      debugPrint('Error initializing ServiceManager: $e');
      debugPrint('Stack trace: $stackTrace');
      _notifyStateChange('initialization_error', e.toString());
      return false;
    }
  }

  /// Start a conversation
  Future<bool> startConversation({String? welcomeMessage}) async {
    if (_isConversationActive) {
      debugPrint('Conversation is already active');
      return true;
    }

    try {
      debugPrint('Starting conversation...');
      
      // 加入RTC频道
      final rtcSuccess = await _rtcService.joinChannel();
      if (!rtcSuccess) {
        _notifyStateChange('rtc_error', 'Failed to join RTC channel');
        return false;
      }
      
      // 启动LLM会话
      final llmSuccess = await _llmService.startConversation(welcomeMessage);
      if (!llmSuccess) {
        _notifyStateChange('llm_error', 'Failed to start LLM conversation');
        await _rtcService.leaveChannel(); // 离开RTC频道
        return false;
      }
      
      _isConversationActive = true;
      _notifyStateChange('conversation_started', 'Conversation started');
      
      // 开始监听音频输入
      await _startAudioCapture();
      
      return true;
    } catch (e, stackTrace) {
      debugPrint('Error starting conversation: $e');
      debugPrint('Stack trace: $stackTrace');
      _notifyStateChange('start_error', e.toString());
      
      // 确保资源被释放
      await _rtcService.leaveChannel();
      await _llmService.stopConversation();
      
      return false;
    }
  }

  /// Stop the conversation
  Future<bool> stopConversation() async {
    if (!_isConversationActive) {
      debugPrint('No active conversation to stop');
      return true;
    }

    try {
      debugPrint('Stopping conversation...');
      
      // 停止音频捕获
      await _stopAudioCapture();
      
      // 停止LLM会话
      await _llmService.stopConversation();
      
      // 离开RTC频道
      await _rtcService.leaveChannel();
      
      _isConversationActive = false;
      _notifyStateChange('conversation_stopped', 'Conversation stopped');
      
      return true;
    } catch (e, stackTrace) {
      debugPrint('Error stopping conversation: $e');
      debugPrint('Stack trace: $stackTrace');
      _notifyStateChange('stop_error', e.toString());
      return false;
    }
  }

  /// Send a text message
  Future<bool> sendTextMessage(String message) async {
    if (!_isConversationActive) {
      debugPrint('Cannot send message: No active conversation');
      return false;
    }

    try {
      // 暂停音频捕获
      await _stopAudioCapture();
      
      // 发送消息到LLM
      final success = await _llmService.sendMessage(message);
      
      // 恢复音频捕获
      await _startAudioCapture();
      
      return success;
    } catch (e, stackTrace) {
      debugPrint('Error sending text message: $e');
      debugPrint('Stack trace: $stackTrace');
      
      // 尝试恢复音频捕获
      try {
        await _startAudioCapture();
      } catch (e) {
        debugPrint('Failed to restart audio capture: $e');
      }
      
      return false;
    }
  }

  /// Start audio capture
  Future<void> _startAudioCapture() async {
    if (!_isCapturingAudio && _isConversationActive) {
      await _asrService.startRecognition();
    }
  }

  /// Stop audio capture
  Future<void> _stopAudioCapture() async {
    if (_isCapturingAudio) {
      await _asrService.stopRecognition();
    }
  }

  /// Handle user message
  void _handleUserMessage(String message) {
    if (!_isConversationActive) return;
    
    debugPrint('Handling user message: $message');
    sendTextMessage(message);
  }

  /// Notify state change
  void _notifyStateChange(String state, String? message) {
    debugPrint('State change: $state, $message');
    if (_onStateChange != null) {
      _onStateChange!(state, message);
    }
  }

  /// Notify message
  void _notifyMessage(String message, bool isUser) {
    if (_onMessage != null) {
      _onMessage!(message, isUser);
    }
  }

  /// Notify audio status change
  void _notifyAudioStatusChange(bool isPlaying) {
    if (_onAudioStatusChange != null) {
      _onAudioStatusChange!(isPlaying);
    }
  }

  /// Dispose all services
  void dispose() {
    _rtcService.dispose();
    _asrService.dispose();
    _ttsService.dispose();
    _llmService.dispose();
    _isConversationActive = false;
    _isAudioPlaying = false;
    _isCapturingAudio = false;
  }
}
