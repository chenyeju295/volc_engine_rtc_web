import 'dart:async';

import 'package:flutter/foundation.dart';

import '../config/config.dart';
import '../utils/web_utils.dart';
import 'rtc_service.dart';
import 'service_interface.dart';

/// Callback for handling state changes
typedef StateChangeCallback = void Function(String state, String? message);

/// Callback for handling text messages
typedef MessageCallback = void Function(String text, bool isUser);

/// Callback for handling audio status changes
typedef AudioStatusCallback = void Function(bool isPlaying);

/// Callback for handling audio devices changes
typedef AudioDevicesCallback = void Function(List<dynamic> devices);

/// Callback for handling AI subtitles
typedef SubtitleCallback = void Function(Map<String, dynamic> subtitle);

/// Service manager for AIGC RTC services
class ServiceManager implements Service {
  /// Services configuration
  final RtcConfig config;

  /// RTC Service
  late final RtcService _rtcService;

  /// Public getter for rtcService
  RtcService get rtcService => _rtcService;

  /// Is initialized
  bool _isInitialized = false;

  /// Is disposed
  bool _isDisposed = false;

  /// Is conversation active
  bool _isConversationActive = false;

  /// List of subscriptions to clean up
  final List<StreamSubscription> _subscriptions = [];

  /// Callback for state changes
  StateChangeCallback? _onStateChange;

  /// Callback for messages
  MessageCallback? _onMessage;

  /// Callback for audio status changes
  AudioStatusCallback? _onAudioStatus;

  /// Callback for audio devices changes
  AudioDevicesCallback? _onAudioDevicesChange;

  /// Callback for AI subtitles
  SubtitleCallback? _onSubtitle;

  /// Device state subscription
  StreamSubscription<bool>? _deviceStateSubscription;

  /// Message subscription
  StreamSubscription<String>? _messageSubscription;

  /// Connection state subscription
  StreamSubscription<String>? _connectionStateSubscription;

  /// Create a new service manager
  ServiceManager({required this.config}) {
    _rtcService = RtcService(config: config);
  }

  /// Set callback for state changes
  void setOnStateChange(StateChangeCallback callback) {
    _onStateChange = callback;
  }

  /// Set callback for text messages
  void setOnMessage(MessageCallback callback) {
    _onMessage = callback;
  }

  /// Set callback for audio status changes
  void setOnAudioStatusChange(AudioStatusCallback callback) {
    _onAudioStatus = callback;
  }

  /// Set callback for audio devices changes
  void setOnAudioDevicesChange(AudioDevicesCallback callback) {
    _onAudioDevicesChange = callback;

    // 如果已经初始化完成，则设置对应的设备变更监听
    if (_isInitialized && !_isDisposed) {
      _setupAudioDeviceListener();
    }
  }

  /// Set callback for AI subtitles
  void setOnSubtitle(SubtitleCallback callback) {
    _onSubtitle = callback;

    // 如果已经初始化完成，则设置对应的字幕监听
    if (_isInitialized && !_isDisposed) {
      _setupSubtitleListener();
    }
  }

  /// Safely execute callback, catching possible exceptions
  void _safeCallback(Function() callback) {
    if (_isDisposed) return;

    try {
      callback();
    } catch (e) {
      debugPrint('Error in callback: $e');
    }
  }

  /// Initialize all services
  @override
  Future<void> initialize() async {
    if (_isInitialized || _isDisposed) return;

    try {
      // Notify state change
      if (_onStateChange != null) {
        _safeCallback(
            () => _onStateChange!('initializing', 'Initializing services...'));
      }

      // First make sure the SDK is loaded
      await WebUtils.waitForSdkLoaded();

      // Initialize RTC service
      await _rtcService.initialize();

      // Subscribe to device state change events
      _deviceStateSubscription =
          _rtcService.deviceStateStream.listen((isAvailable) {
        if (_onStateChange != null) {
          _safeCallback(() => _onStateChange!(
              isAvailable ? 'ready' : 'error',
              isAvailable
                  ? 'Devices are ready'
                  : 'Audio/video devices not available'));
        }
      }, onError: (error) {
        debugPrint('Device state error: $error');
        if (_onStateChange != null) {
          _safeCallback(
              () => _onStateChange!('error', 'Device state error: $error'));
        }
      });

      // Setup audio device listener if callback is set
      if (_onAudioDevicesChange != null) {
        _setupAudioDeviceListener();
      }

      // Setup subtitle listener if callback is set
      if (_onSubtitle != null) {
        _setupSubtitleListener();
      }

      _isInitialized = true;

      // Notify state change
      if (_onStateChange != null) {
        _safeCallback(() =>
            _onStateChange!('ready', 'Services initialized successfully'));
      }

      debugPrint('Service manager initialized successfully');
    } catch (e) {
      debugPrint('Failed to initialize service manager: $e');
      if (_onStateChange != null) {
        _safeCallback(
            () => _onStateChange!('error', 'Failed to initialize: $e'));
      }
      rethrow;
    }
  }

  /// Set up audio device change listener
  void _setupAudioDeviceListener() {
    try {
      // Subscribe to audio devices change stream
      final audioDevicesSubscription =
          _rtcService.audioDevicesStream.listen((devices) {
        if (_onAudioDevicesChange != null) {
          _safeCallback(() => _onAudioDevicesChange!(devices));
        }
      }, onError: (error) {
        debugPrint('Audio devices stream error: $error');
      });

      // Add the subscription to be disposed later
      _subscriptions.add(audioDevicesSubscription);
    } catch (e) {
      debugPrint('Error setting up audio device listener: $e');
    }
  }

  /// Set up AI subtitle listener
  void _setupSubtitleListener() {
    try {
      // Subscribe to RTC subtitle stream
      final subtitleSubscription =
          _rtcService.subtitleStream.listen((subtitle) {
        if (_onSubtitle != null && subtitle != null) {
          _safeCallback(() => _onSubtitle!(subtitle));
        } else if (_onSubtitle != null && subtitle == null) {
          // 清空字幕
          _safeCallback(() => _onSubtitle!({}));
        }
      }, onError: (error) {
        debugPrint('Subtitle stream error: $error');
      });

      // Add the subscription to be disposed later
      _subscriptions.add(subtitleSubscription);
      debugPrint('Subtitle listener set up successfully');
    } catch (e) {
      debugPrint('Error setting up subtitle listener: $e');
    }
  }

  /// Set up audio status listener
  void _setupAudioStatusListener() {
    try {
      // Subscribe to RTC audio status stream
      final audioStatusSubscription =
          _rtcService.audioStatusStream.listen((isPlaying) {
        if (_onAudioStatus != null) {
          _safeCallback(() => _onAudioStatus!(isPlaying));
        }
      }, onError: (error) {
        debugPrint('Audio status stream error: $error');
      });

      // Add the subscription to be disposed later
      _subscriptions.add(audioStatusSubscription);
      debugPrint('Audio status listener set up successfully');
    } catch (e) {
      debugPrint('Error setting up audio status listener: $e');
    }
  }

  /// Start a conversation with AIGC
  Future<bool> startConversation({
    String? welcomeMessage,
    String? businessId,
  }) async {
    if (!_isInitialized || _isDisposed) {
      debugPrint('Service manager not initialized or disposed');
      return false;
    }

    try {
      // Device preparation
      final hasMicrophone = await _rtcService.requestMicrophoneAccess();
      if (!hasMicrophone) {
        if (_onStateChange != null) {
          _safeCallback(
              () => _onStateChange!('error', 'Microphone access denied'));
        }
        return false;
      }

      // Notify state change
      if (_onStateChange != null) {
        _safeCallback(
            () => _onStateChange!('connecting', 'Starting conversation...'));
      }

      // Start RTC session
      final success = await _rtcService.startConversation(
        welcomeMessage: welcomeMessage,
      );

      _isConversationActive = success != null;

      // Notify state change
      if (_onStateChange != null) {
        _safeCallback(() => _onStateChange!(
            success != null ? 'connected' : 'error',
            success != null
                ? 'Conversation started'
                : 'Failed to start conversation'));
      }

      return success != null;
    } catch (e) {
      debugPrint('Error starting conversation: $e');
      if (_onStateChange != null) {
        _safeCallback(
            () => _onStateChange!('error', 'Error starting conversation: $e'));
      }
      return false;
    }
  }

  /// Stop the conversation
  Future<bool> stopConversation() async {
    try {
      final result = await _rtcService.stopConversation() ?? false;
      return result;
    } catch (e) {
      debugPrint('Error stopping conversation: $e');
      return false;
    }
  }

  /// Send a text message
  Future<bool> sendTextMessage(String message) async {
    if (!_isInitialized || _isDisposed || !_isConversationActive) {
      return false;
    }

    try {
      // Notify message event
      if (_onMessage != null) {
        _safeCallback(() => _onMessage!(message, true));
      }

      // Send message to RTC service
      return await _rtcService.sendMessage(message);
    } catch (e) {
      debugPrint('Error sending message: $e');
      return false;
    }
  }

  /// Speak a text using TTS
  Future<bool> speakText(String text) async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      // Notify message event
      if (_onMessage != null) {
        _safeCallback(() => _onMessage!(text, false));
      }

      return true;
    } catch (e) {
      debugPrint('Error speaking text: $e');
      return false;
    }
  }

  /// Stop speaking
  void _stopSpeaking() {
    if (!_isInitialized || _isDisposed) {
      return;
    }
  }

  /// Request microphone access
  Future<bool> requestMicrophoneAccess() async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    return await _rtcService.requestMicrophoneAccess();
  }

  /// Request camera access
  Future<bool> requestCameraAccess() async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    return await _rtcService.requestCameraAccess();
  }

  /// Get the RTC service instance for direct access
  dynamic getRtcService() {
    return _rtcService;
  }

  /// Dispose all services
  @override
  Future<void> dispose() async {
    if (_isDisposed) return;

    try {
      _isDisposed = true;
      _isInitialized = false;
      _isConversationActive = false;

      await _deviceStateSubscription?.cancel();
      await _messageSubscription?.cancel();
      await _connectionStateSubscription?.cancel();
      // Cancel additional subscriptions
      for (var subscription in _subscriptions) {
        await subscription.cancel();
      }
      _subscriptions.clear();

      // Dispose services
      await _rtcService.dispose();

      debugPrint('Service manager disposed');
    } catch (e) {
      debugPrint('Error disposing service manager: $e');
    }
  }

  /// 测试AI字幕（仅用于开发和调试）
  Future<bool> testAISubtitle(String text, bool isFinal) async {
    try {
      final result =
          await _rtcService?.testAISubtitle(text, isFinal: isFinal) ?? false;
      return result;
    } catch (e) {
      debugPrint('Error testing AI subtitle: $e');
      return false;
    }
  }

  /// Join a room
  Future<bool> joinRoom({String? serverUrl}) async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      return await _rtcService.joinRoom(serverUrl: serverUrl);
    } catch (e) {
      debugPrint('Error joining room: $e');
      return false;
    }
  }

  /// Leave the room
  Future<bool> leaveRoom() async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      return await _rtcService.leaveRoom();
    } catch (e) {
      debugPrint('Error leaving room: $e');
      return false;
    }
  }

  /// Interrupt the conversation
  Future<bool> interruptConversation() async {
    if (!_isInitialized || _isDisposed || !_isConversationActive) {
      return false;
    }

    try {
      return await _rtcService.interruptConversation();
    } catch (e) {
      debugPrint('Error interrupting conversation: $e');
      return false;
    }
  }

  /// Resume audio playback
  Future<bool> resumeAudioPlayback() async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      return await _rtcService.resumeAudioPlayback();
    } catch (e) {
      debugPrint('Error resuming audio playback: $e');
      return false;
    }
  }

  /// Send a message to the AI
  Future<bool> sendMessage(String message) async {
    if (!_isInitialized || _isDisposed || !_isConversationActive) {
      return false;
    }

    try {
      return await _rtcService.sendMessage(message);
    } catch (e) {
      debugPrint('Error sending message: $e');
      return false;
    }
  }

  /// Get audio input devices
  Future<List<Map<String, String>>> getAudioInputDevices() async {
    if (!_isInitialized || _isDisposed) {
      return [];
    }

    try {
      return await _rtcService.getAudioInputDevices();
    } catch (e) {
      debugPrint('Error getting audio input devices: $e');
      return [];
    }
  }

  /// Get audio output devices
  Future<List<Map<String, String>>> getAudioOutputDevices() async {
    if (!_isInitialized || _isDisposed) {
      return [];
    }

    try {
      return await _rtcService.getAudioOutputDevices();
    } catch (e) {
      debugPrint('Error getting audio output devices: $e');
      return [];
    }
  }

  /// Set audio capture device
  Future<bool> setAudioCaptureDevice(String deviceId) async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      return await _rtcService.setAudioCaptureDevice(deviceId);
    } catch (e) {
      debugPrint('Error setting audio capture device: $e');
      return false;
    }
  }

  /// Set audio playback device
  Future<bool> setAudioPlaybackDevice(String deviceId) async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      return await _rtcService.setAudioPlaybackDevice(deviceId);
    } catch (e) {
      debugPrint('Error setting audio playback device: $e');
      return false;
    }
  }

  /// Start audio capture
  Future<bool> startAudioCapture(String? deviceId) async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      return await _rtcService.startAudioCapture(deviceId);
    } catch (e) {
      debugPrint('Error starting audio capture: $e');
      return false;
    }
  }

  /// Stop audio capture
  Future<bool> stopAudioCapture() async {
    if (!_isInitialized || _isDisposed) {
      return false;
    }

    try {
      return await _rtcService.stopAudioCapture();
    } catch (e) {
      debugPrint('Error stopping audio capture: $e');
      return false;
    }
  }
}
