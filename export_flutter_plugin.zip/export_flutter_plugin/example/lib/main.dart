import 'package:flutter/material.dart';
import 'package:rtc_aigc_plugin/rtc_aigc_plugin.dart';
import 'package:rtc_aigc_plugin/src/config/config.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RTC AIGC Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const RtcAigcDemo(),
    );
  }
}

class RtcAigcDemo extends StatefulWidget {
  const RtcAigcDemo({Key? key}) : super(key: key);

  @override
  _RtcAigcDemoState createState() => _RtcAigcDemoState();
}

class _RtcAigcDemoState extends State<RtcAigcDemo> {
  String _status = 'Not initialized';
  final List<String> _messages = [];
  bool _isInitialized = false;
  bool _isConversationActive = false;
  bool _isSpeaking = false;
  bool _isListening = false;

  final TextEditingController _messageController = TextEditingController();
  
  // 添加一个滚动控制器用于消息列表
  final ScrollController _messagesScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _initializePlugin();
  }

  Future<void> _initializePlugin() async {
    try {
      // 定义回调函数
      void Function(String, String?) stateChangeHandler =
          (String state, String? message) {
        print('State changed: $state, $message');
        setState(() {
          _status = '$state${message != null ? ': $message' : ''}';
          
          // 检查是否为音频状态变化
          if (state == 'audio_playing') {
            _isSpeaking = true;
          } else if (state == 'audio_stopped') {
            _isSpeaking = false;
          } else if (state == 'listening') {
            _isListening = true;
          } else if (state == 'stopped_listening') {
            _isListening = false;
          }
        });
      };

      void Function(String, bool) messageHandler = (String text, bool isUser) {
        print('Message received: $text (isUser: $isUser)');
        setState(() {
          _messages.add('${isUser ? 'You' : 'AI'}: $text');
          
          // 如果是AI消息，滚动到底部
          if (!isUser) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (_messagesScrollController.hasClients) {
                _messagesScrollController.animateTo(
                  _messagesScrollController.position.maxScrollExtent,
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOut,
                );
              }
            });
          }
        });
      };

      void Function(bool) audioStatusHandler = (bool isPlaying) {
        print('Audio status changed: $isPlaying');
        setState(() {
          _isSpeaking = isPlaying;
        });
      };

      // 初始化插件
      final success = await RtcAigcPlugin.initialize(
        // RTC AppId - 火山引擎RTC服务的AppId 
        // 请替换为您的实际AppId
        appId: '67eb953062b4b601a6df1348',
        
        // 房间ID - 保持小写，与token匹配
        roomId: 'room1',
        
        // 用户ID - 保持小写，与token匹配
        userId: 'user1',
        
        // Token - 使用与roomId和userId匹配的token
        // 请替换为您在火山引擎控制台生成的有效token
        token: '00167eb953062b4b601a6df1348QADVfHICjK3rZwzo9GcFAFJvb20xBQBVc2VyMQYAAAAM6PRnAQAM6PRnAgAM6PRnAwAM6PRnBAAM6PRnBQAM6PRnIADbxOsGQGjsXsg4abi5J1a1ntWmbvm8iWCXdTlrgMGQzA==',
        
        // 服务器URL - 使用HTTP服务时指定
        serverUrl: 'http://localhost:3001/proxyAIGCFetch',
        
        // ASR配置 - 语音识别服务配置
        asrConfig: AsrConfig(
          // ASR AppId - 替换为您的语音识别AppId
          appId: '4799544484',
          
          // 可选：指定集群
          cluster: 'volcano_asr',
        ),
        
        // TTS配置 - 语音合成服务配置
        ttsConfig: TtsConfig(
          // TTS AppId - 替换为您的语音合成AppId
          appId: '4799544484',
          
          // 语音类型 - 例如通用女声
          voiceType: 'BV001_streaming',
          
          // 集群名称
          cluster: 'volcano_tts',
        ),
        
        // LLM配置 - 大型语言模型配置
        llmConfig: LlmConfig(
          // LLM AppId - 替换为您的大模型AppId
          appId: '4799544484',
          
          // 模型名称 - 例如方舟模型
          modelName: 'Doubao-pro-32k',
          
          // 欢迎语
          welcomeSpeech: '您好，我是AI助手，有什么可以帮您的？',
          
          // 系统消息 - 设置AI的角色和行为
          systemMessages: [
            '你是一个专业、友好的AI助手，能够提供准确的信息和有用的建议。'
          ],
        ),
        
        // 回调函数
        onStateChange: stateChangeHandler,
        onMessage: messageHandler,
        onAudioStatusChange: audioStatusHandler,
      );

      setState(() {
        _isInitialized = success;
        if (success) {
          _status = 'Initialized successfully';
        } else {
          _status = 'Initialization failed';
        }
      });
    } catch (e, s) {
      print('Exception during initialization: $e');
      print('Stack trace: $s');
      setState(() {
        _status = 'Error: $e';
      });
    }
  }

  Future<void> _startConversation() async {
    try {
      final success = await RtcAigcPlugin.startConversation(
        welcomeMessage: '您好，我是AI助手，很高兴为您服务!',
      );
      setState(() {
        _isConversationActive = success;
        _status = success ? 'Conversation started' : 'Failed to start conversation';
      });
    } catch (e) {
      print('Error starting conversation: $e');
      setState(() {
        _status = 'Error: $e';
      });
    }
  }

  Future<void> _stopConversation() async {
    try {
      final success = await RtcAigcPlugin.stopConversation();
      setState(() {
        _isConversationActive = !success;
        _status = success ? 'Conversation stopped' : 'Failed to stop conversation';
      });
    } catch (e) {
      print('Error stopping conversation: $e');
      setState(() {
        _status = 'Error: $e';
      });
    }
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.isEmpty) return;

    final message = _messageController.text;
    _messageController.clear();

    try {
      final success = await RtcAigcPlugin.sendTextMessage(message);
      if (!success) {
        setState(() {
          _status = 'Failed to send message';
        });
      }
    } catch (e) {
      print('Error sending message: $e');
      setState(() {
        _status = 'Error: $e';
      });
    }
  }

  @override
  void dispose() {
    RtcAigcPlugin.dispose();
    _messageController.dispose();
    _messagesScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RTC AIGC Demo'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _initializePlugin,
            tooltip: 'Reinitialize',
          ),
        ],
      ),
      body: Column(
        children: [
          // Status bar
          Container(
            padding: const EdgeInsets.all(8.0),
            color: _isInitialized ? Colors.green.shade100 : Colors.red.shade100,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Status: $_status',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (_isSpeaking)
                  const Icon(Icons.volume_up, color: Colors.blue),
                if (_isListening)
                  const Icon(Icons.mic, color: Colors.red),
              ],
            ),
          ),

          // Messages list
          Expanded(
            child: ListView.builder(
              controller: _messagesScrollController,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                final isUser = message.startsWith('You:');

                return ListTile(
                  leading: Icon(
                    isUser ? Icons.person : Icons.smart_toy,
                    color: isUser ? Colors.blue : Colors.green,
                  ),
                  title: Text(message),
                );
              },
            ),
          ),

          // Input area
          Container(
            padding: const EdgeInsets.all(8.0),
            color: Colors.grey.shade200,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: 'Type a message...',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8.0),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _sendMessage,
                  tooltip: 'Send message',
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _isConversationActive ? _stopConversation : _startConversation,
        tooltip: _isConversationActive ? 'Stop conversation' : 'Start conversation',
        child: Icon(_isConversationActive ? Icons.stop : Icons.play_arrow),
      ),
    );
  }
}
