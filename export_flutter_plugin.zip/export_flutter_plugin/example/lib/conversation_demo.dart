import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:rtc_aigc_plugin/rtc_aigc_plugin.dart';
import 'widgets/conversation_view.dart'; // 导入本地的会话视图组件

class ConversationDemo extends StatefulWidget {
  const ConversationDemo({Key? key}) : super(key: key);

  @override
  State<ConversationDemo> createState() => _ConversationDemoState();
}

class _ConversationDemoState extends State<ConversationDemo> {
  // 直接创建RTC服务实例
  late RtcAigcPlugin _rtcPlugin;

  // 控制器
  final TextEditingController _messageController = TextEditingController();

  // 消息流控制器
  final StreamController<Map<String, dynamic>> _messageStreamController =
      StreamController<Map<String, dynamic>>.broadcast();

  // 状态流控制器
  final StreamController<Map<String, dynamic>> _stateStreamController =
      StreamController<Map<String, dynamic>>.broadcast();

  // 会话是否已开始
  bool _isConversationStarted = false;

  // 是否正在发送消息
  bool _isSendingMessage = false;

  // 用户ID
  String _userId = 'User${Random().nextInt(10000)}';

  // AI会话ID
  String _botId = 'BotID001';

  @override
  void initState() {
    super.initState();
    _initializePlugin();
  }

  // 初始化插件
  void _initializePlugin() {
    _rtcPlugin = RtcAigcPlugin();
    _setupEventListeners();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _messageStreamController.close();
    _stateStreamController.close();

    // 如果会话已开始，停止它
    if (_isConversationStarted) {
      RtcAigcPlugin.stopConversation();
    }

    super.dispose();
  }

  // 设置事件监听器
  void _setupEventListeners() {
    // // 监听字幕消息
    // _rtcPlugin.onSubtitle.listen((event) {
    //   final subtitle = event['text'] as String? ?? '';
    //   final isFinal = event['isFinal'] as bool? ?? false;
    //
    //   _messageStreamController.add({
    //     'userId': _botId,
    //     'text': subtitle,
    //     'timestamp': DateTime.now().millisecondsSinceEpoch,
    //     'isFinal': isFinal,
    //   });
    // });
    //
    // // 监听AI状态变化
    // _rtcPlugin.onStateChange.listen((event) {
    //   final stateCode = event.split(':')[0].trim();
    //   final isThinking = stateCode == 'THINKING';
    //   final isTalking = stateCode == 'SPEAKING';
    //
    //   _stateStreamController.add({
    //     'state': stateCode,
    //     'isThinking': isThinking,
    //     'isTalking': isTalking,
    //   });
    // });
    //
    // // 监听消息
    // _rtcPlugin.onMessage.listen((event) {
    //   final text = event.$1;
    //   final isUser = event.$2;
    //
    //   debugPrint('收到消息: ${isUser ? "用户" : "AI"} - $text');
    //
    //   // 如果是AI消息，可以在这里处理
    //   if (!isUser) {
    //     // 这里不添加到消息流，因为已经通过onSubtitle处理了
    //   }
    // });
  }

  // 开始会话
  Future<void> _startConversation() async {
    setState(() {
      _isSendingMessage = true;
    });

    try {
      final success = await RtcAigcPlugin.startConversation(
        welcomeMessage: 'Hello, how can I help you today?',
      );

      if (success) {
        setState(() {
          _isConversationStarted = true;
        });

        // 发送系统消息
        _messageStreamController.add({
          'userId': 'system',
          'text': '会话已开始，请开始对话',
          'timestamp': DateTime.now().millisecondsSinceEpoch,
          'isFinal': true,
        });
      } else {
        _showErrorSnackBar('开始会话失败');
      }
    } catch (e) {
      _showErrorSnackBar('开始会话出错: $e');
    } finally {
      setState(() {
        _isSendingMessage = false;
      });
    }
  }

  // 停止会话
  Future<void> _stopConversation() async {
    setState(() {
      _isSendingMessage = true;
    });

    try {
      final success = await RtcAigcPlugin.stopConversation();

      setState(() {
        _isConversationStarted = false;
      });

      // 发送系统消息
      _messageStreamController.add({
        'userId': 'system',
        'text': '会话已结束',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'isFinal': true,
      });
    } catch (e) {
      _showErrorSnackBar('停止会话出错: $e');
    } finally {
      setState(() {
        _isSendingMessage = false;
      });
    }
  }

  // 发送消息
  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    // 如果会话未开始，先开始它
    if (!_isConversationStarted) {
      await _startConversation();
    }

    setState(() {
      _isSendingMessage = true;
    });

    // 清空输入框
    _messageController.clear();

    // 先添加用户消息到UI
    _messageStreamController.add({
      'userId': _userId,
      'text': message,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'isFinal': true,
    });

    try {
      await RtcAigcPlugin.sendTextMessage(message);
    } catch (e) {
      _showErrorSnackBar('发送消息出错: $e');
    } finally {
      setState(() {
        _isSendingMessage = false;
      });
    }
  }

  // 打断对话
  Future<void> _interruptConversation() async {
    try {
      // 这里我们模拟打断功能，因为插件可能没有直接提供这个方法
      await RtcAigcPlugin.stopConversation();
      await Future.delayed(const Duration(milliseconds: 300));
      await RtcAigcPlugin.startConversation();

      // 发送状态更新
      _stateStreamController.add({
        'state': 'INTERRUPTED',
        'isThinking': false,
        'isTalking': false,
      });
    } catch (e) {
      _showErrorSnackBar('打断对话出错: $e');
    }
  }

  // 显示错误提示
  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI对话演示'),
        actions: [
          if (_isConversationStarted)
            IconButton(
              icon: const Icon(Icons.stop),
              tooltip: '停止会话',
              onPressed: _stopConversation,
            )
          else
            IconButton(
              icon: const Icon(Icons.play_arrow),
              tooltip: '开始会话',
              onPressed: _startConversation,
            ),
        ],
      ),
      body: Column(
        children: [
          // 会话视图
          Expanded(
            child: ConversationView(
              messageHistoryStream: _messageStreamController.stream,
              stateStream: _stateStreamController.stream,
              userId: _userId,
              botId: _botId,
              onInterrupt: _interruptConversation,
            ),
          ),

          // 输入区域
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, -1),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: '输入消息...',
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(
                          horizontal: 16.0, vertical: 12.0),
                    ),
                    minLines: 1,
                    maxLines: 5,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                    enabled: !_isSendingMessage,
                  ),
                ),
                const SizedBox(width: 8.0),
                IconButton(
                  icon: _isSendingMessage
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.send),
                  onPressed: _isSendingMessage ? null : _sendMessage,
                  color: Theme.of(context).primaryColor,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
